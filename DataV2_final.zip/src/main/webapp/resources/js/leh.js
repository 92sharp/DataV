
var margin = {top: 70, right: 35, bottom: 10, left: 35},
    width = 400 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom

// Create the svg area


// ajax로 데이터 가져오기
var url="/data/video"; // 데이터 가져오는 경로
console.log(url); // 경로 확인
var videoList;
$.ajax({      
    type:"POST",  
    url:url,      
         
    success:function(args){
        console.log(args);
        
        
        var svg = d3.select("#leh")
        .append("svg")
          .attr("width", width + margin.left + margin.right)
          .attr("height", height + margin.top + margin.bottom)
        .append("g")
          .attr("transform", "translate(30,0)");

        
     // 그래프에 그리는 데이터 생성
       var data = [];
       for(var i=0;i<args.length;i++){
          var x = args[i].user_Score;
          var y = args[i].critic_Score;
          data.push({
             x:x,
             y:y,
          });
        }
       
       // Add X axis
         var x = d3.scaleLinear()
           .domain([0,10 ])
           .range([ 0, width ]);
         svg.append("g")
           .attr("transform", "translate(0," + height + ")")
           .call(d3.axisBottom(x))
           .append("text")
           .attr("y", 30)
           .attr("x", (width + margin.left + margin.right)/2)
           .attr("text-anchor", "end")
           .attr("stroke", "black")
           .text("user_Score");

         // Add Y axis
         var y = d3.scaleLinear()
           .domain([0, 100])
           .range([ height, 0]);
         svg.append("g")
           .call(d3.axisLeft(y))
           .append("text")
           .attr("transform", "rotate(-90)")
           .attr("x", -((height + margin.top + margin.bottom)/2))
           .attr("dy", -26.5)
           .attr("text-anchor", "end")
           .attr("stroke", "black")
           .text("critic_Score");

         // Add dots
         svg.append('g')
           .selectAll("dot")
           .data(data)
           .enter()
           .append("circle")
             .attr("cx", function (d) { return x(d.x); } )
             .attr("cy", function (d) { return y(d.y); } )
             .attr("r", 1.5)
             .style("fill", "#0100FF")
   
    }
});




