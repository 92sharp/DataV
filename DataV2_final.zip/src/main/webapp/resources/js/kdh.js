
////////////////// xxx 그래프 /////////////////////////
//Graph dimension
var margin = {top: 20, right: 10, bottom: 10, left: 50},
    width = 400 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom
    

// ajax로 데이터 가져오기
var url="/data/video"; // 데이터 가져오는 경로
console.log(url); // 경로 확인
var videoList;
$.ajax({      
    type:"POST",  
    url:url,      
    success:function(args){
       
       videoList=args;
       
       var year;
       var totA=[0];
       var totB=[0];
       var totC=[0];
       var totD=[0];
       var totE=[0];
       var totF=[0];
       
       for(var i=0; i<args.length;i++){
          
          var year=args[i].year_of_Release;
          var glb=args[i].global_Sales;
          
          if(year>=1985 && year<=1999){
             totA[0]+=glb;
          }
          if(year>=2000 && year<=2003){
             totB[0]+=glb;
          }
          if(year>=2004 && year<=2006){
             totC[0]+=glb;
          }
          if(year>=2007 && year<=2009){
             totD[0]+=glb;
          }
          if(year>=2010 && year<=2012){
             totE[0]+=glb;
          }
          if(year>=2013 && year<=2016){
             totF[0]+=glb;
          }
       }
       
       
       var dataset=[{x:'85~99',y:Math.floor(totA)},{x:'00~03',y:Math.floor(totB)},
          {x:'04~06',y:Math.floor(totC)},{x:'07~09',y:Math.floor(totD)},{x:'10~12',y:Math.floor(totE)},
          {x:'13~16(년)',y:Math.floor(totF)}];
       
       var color = d3.scaleOrdinal(d3.schemeCategory20c); 
       
       
       // Create the svg area
       var svg = d3.select("#kdh")
         .append("svg")
           .attr("width", width + margin.left + margin.right)
           .attr("height", height + margin.top + margin.bottom)
         .append("g")
           .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
       
       var width=240;
    
       var svgG = svg.append("g")                                              
           .attr("transform", "translate(30, 0)");
       
       var xScale = d3.scaleBand()                                       
        .domain(dataset.map(function(d) { return d.x;} ))
        .range([0, width]).padding(0.2);

    
       var yScale = d3.scaleLinear()                                            
           .domain([0, d3.max(dataset, function(d){ return d.y+10; })])
           .range([height, 0]);  
       

      svgG.append("g")           
       .attr("class", "grid")
       .attr("transform", "translate(0," + height + ")")
       .call(d3.axisBottom(xScale)
           .tickSize(-height)
       );
   
      svgG.append("g")
       .attr("class", "grid")
       .call(d3.axisLeft(yScale)
           .ticks(5)
           .tickSize(-width)
       );    
      
      
    
       var barG = svgG.append("g");
        
       barG.selectAll("rect")
           .data(dataset)
           .enter().append("rect")
               .attr("class", "bar")
               .attr("height", function(d, i) {return height-yScale(d.y)})
               .attr("width", xScale.bandwidth())
               .attr("x", function(d, i) {return xScale(d.x)})
               .attr("y", function(d, i) {return yScale(d.y)})
               .attr("fill", function(d,i) {
                  return color(i); //색상 리턴
               })
               .on("mouseover", function() { tooltip.style("display", null); })
               .on("mouseout",  function() { tooltip.style("display", "none"); })
               .on("mousemove", function(d) {
                   var xP = d3.mouse(this)[0];
                   var yP = d3.mouse(this)[1] - 25;
                   tooltip.attr("transform", "translate(" + xP + "," + yP + ")");
                   tooltip.select("text").text(d.y);
               });        
           
       barG.selectAll("text")
           .data(dataset)
           .enter().append("text")
           .text(function(d) {return d.y})
               .attr("class", "text")
               .attr("x", function(d, i) {return xScale(d.x)+xScale.bandwidth()/2})
               .style("text-anchor", "middle")
               .attr("font-size", "10px")
               .attr("y", function(d, i) {return yScale(d.y) + 15});

       var tooltip = svg.append("g")
           .attr("class", "tooltip")
           .style("display", "none");
           
       tooltip.append("rect")
           .attr("width", 30)
           .attr("height", 20)
           .attr("fill", "white");

       tooltip.append("text")
       
           .attr("x", 15)
           .attr("dy", "1em")
           .style("text-anchor", "middle");
       

    }
});

