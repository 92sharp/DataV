
//Graph dimension
var margin = {top: 50, right: 50, bottom: 50, left: 50},
    width = 400 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom

// Create the svg area

// ajax로 데이터 가져오기
var url="/data/video"; // 데이터 가져오는 경로
//console.log(url); // 경로 확인
var videoList; 
$.ajax({      
    type:"POST",  
    url:url,      
         
    success:function(args){
       videoList = args;
      
        // 그래프에 그리는 데이터 생성
        // 각 항목의 평균 구하기
        var mean = [];
        
        for(var i=0;i<=10;i++){
           mean.push(0);
        }
        for(var i=0;i<args.length;i++){
           var k = 0;
           for(var j=0;j<16;j++){
              var col = Object.keys(args[i])[j];
              var check = args[i][col];
              
              if(!(check >= 0 && check <= 100000)){
                 continue;
              }
              if(!isFinite(mean[k])) console.log(mean[k]);
              mean[k++] += args[i][col];
              
           }
        }
        for(var i=0;i<=10;i++){
           mean[i] /= args.length;
           if(isFinite(mean[i])) console.log("dasdsa");
        }
           
        //console.log(mean);
        
        
        // 각 항목의 표준편차 구하기
        var stddev = [];
        for(var i=0;i<10;i++){
           stddev.push(0);
        }
        for(var i=0;i<args.length;i++){
           var k = 0;
           for(var j=0;j<16;j++){
              var a = Object.keys(args[i])[j];
              
              var check = args[i][a];
              if(!(check >= 0 && check <= 100000)){
                 continue;
              }
              
              var b = (args[i][a] - mean[k]);
              stddev[k++] += b*b;
           }
        }
        for(var i=0;i<10;i++){
           //stddev[i] = stddev[i]/args.length;
           stddev[i] = Math.sqrt(stddev[i]/args.length);
        }
        //console.log(stddev);
        
        // 각 (x,y) 항목의 공분산 구하기
        var corr = [];
        for(var i=0;i<45;i++){
           corr.push(0);
        }

        
        for(var i=0;i<args.length;i++){
           var t = 0;
           var v = 0;
           var w = 0;
           for(var j=0;j<16;j++){
              var a = Object.keys(args[i])[j];
              var check = args[i][a];
              if(!(check >= 0 && check <= 100000)){
                 continue;
              }
              w = v+1;
              for(var k=j+1;k<16;k++){
                 var b = Object.keys(args[i])[k];
                 var check = args[i][b];
                  if(!(check >= 0 && check <= 100000)){
                     continue;
                  }
                 var x = args[i][a];
                 var y = args[i][b];
                 corr[t] += (x-mean[v])*(y-mean[w]);
                 //if(isNaN(corr[t])) console.log(t+","+v+","+w);
                 t++;
                 w++;
              }
              v++;
              
           }
        }
        for(var i=0;i<45;i++){
           corr[i] = corr[i]/args.length;
        }
        
        //console.log(corr);
        
        // 각 (x,y) 항목의 상관계수 구하기
        var data = []; // 여기에 만든 데이터를 다 넣어준다
        var t = 0;
        var v = 0;
        for(var i=0;i<16;i++){
           var x = Object.keys(args[0])[i];
           var check = args[i][x];
          if(!(check >= 0 && check <= 100000)){
             continue;
          }
           var w = v+1;
           for(var j=i;j<16;j++){
              var y = Object.keys(args[0])[j];
              
              var check = args[i][y];
              if(!(check >= 0 && check <= 100000)){
                 continue;
              }
              
              if(i == j){
                 var value = 1;
                 data.push({
                     x:x,
                     y:y,
                     value: +value // x랑 y이 같은 컬럼이기 때문에 1
                  });
                 data.push({
                     x:y,
                     y:x,
                     value: +value // x랑 y이 같은 컬럼이기 때문에 1
                  });
              }
              else{
                 var value = corr[t]/(stddev[v]*stddev[w]); // x와 y의 상관계수 값
                 data.push({
                     x:x, 
                     y:y, 
                     value: +value // x와 y의 상관계수의 값을 넣어준다
                  });
                 data.push({
                     x:y, 
                     y:x, 
                     value: +value // x와 y의 상관계수의 값을 넣어준다
                  });
                  t += 1;
                  w++;
              }
           }
           v++;
        }
        
        console.log(data); // 상관계수 데이터 확인
        // List of all variables and number of them
        var domain = d3.set(data.map(function(d) { return d.x })).values()
        var num = Math.sqrt(data.length)
        //console.log(domain)
      
        // Create a color scale
        var color = d3.scaleLinear()
          .domain([-1, 0, 1])
          .range(["#F15F5F", "#fff", "#0100FF"]);
          //.range(["#B22222", "#fff", "#000080"]);
           
        // Create a size scale for bubbles on top right. Watch out: must be a rootscale!
        var size = d3.scaleSqrt()
          .domain([0, 1])
          .range([0, 9]);

        // X scale
        var x = d3.scalePoint()
          .range([0, width])
          .domain(domain)

        // Y scale
        var y = d3.scalePoint()
          .range([0, height])
          .domain(domain)

          var svg = d3.select("#lsj")
  .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
          
        // Create one 'g' element for each cell of the correlogram
        var cor = svg.selectAll(".cor")
          .data(data)
          .enter()
          .append("g")
            .attr("class", "cor")
            .attr("transform", function(d) {
              return "translate(" + x(d.x) + "," + y(d.y) + ")";
            });

        // Low left part + Diagonal: Add the text with specific color
        cor
          .filter(function(d){
            var ypos = domain.indexOf(d.y);
            var xpos = domain.indexOf(d.x);
            //console.log(xpos+":"+ypos);
            return xpos <= ypos;
          })
          .append("text")
            .attr("y", 5)
            .text(function(d) {
              if (d.x === d.y) {
                return 1; // 
              } else {
                return d.value.toFixed(2);
              }
            })
            .style("font-size", 10)
            .style("text-align", "center")
            .style("fill", function(d){
              if (d.x === d.y) {
                return "#000";
              } else {
                return color(d.value);
              }
            });

        // Up right part: add circles
        cor
          .filter(function(d){
            var ypos = domain.indexOf(d.y);
            var xpos = domain.indexOf(d.x);
            return xpos > ypos;
          })
          .append("circle")
            .attr("r", function(d){ return size(Math.abs(d.value)) })
            .style("fill", function(d){
              if (d.x === d.y) {
                return "#000";
              } else {
                return color(d.value);
              }
            })
            .style("opacity", 0.8)
        //console.log(wineList);

    }
});



$( document ).ready(function() {
    load_movielist();
});

var show=0;

function load_movielist(){
    var movieList;
    var html;
    $("#load_data").click(function(){  
    	if(show==0){
        var url="/data/video";  
        //var params="param1="+param1+"¶m2="+param1;  
  
        $.ajax({      
            type:"POST",  
            url:url,      
            //data:params,      
            success:function(args){
            	
            	
            	
                for(var i=0;i<7;i++){
                    html = "<tr>"
                            + "<td>" + args[i].platform + "</td>"
                            + "<td>" + args[i].year_of_Release + "</td>"
                            + "<td>" + args[i].genre + "</td>"
                            + "<td>" + args[i].na_Sales + "</td>"
                            + "<td>" + args[i].eu_Sales + "</td>"
                            + "<td>" + args[i].jp_Sales + "</td>"
                            + "<td>" + args[i].other_Sales + "</td>"
                            + "<td>" + args[i].global_Sales + "</td>"
                            + "<td>" + args[i].critic_Score + "</td>"
                            + "<td>" + args[i].critic_Count + "</td>"
                            + "<td>" + args[i].user_Score + "</td>"
                            + "<td>" + args[i].user_Count + "</td>"
                            "</tr>";
                    $("#dataList").append(html);
                }
                
                //console.log(args);
            },   
            beforeSend:function(){
                $("#dataList").empty();  
            },
            error:function(e){  
                alert(e.responseText);  
            }  
        
            
        });show=2;  
      
    }else if(show==1){
        $("#dataList").show();
        console.log("쇼");
        show=2;
     }//false 상태실행
     else if(show==2) {
        //button = false;
        $("#dataList").hide();
        console.log('하이드');
        show=1;
        //location.href='/data/visual/Visual'
        }
});
    
}