var populationList;
var url="/data/Vgsales";
$.ajax({
			type:"POST",
			url:url,
			success:function(args){
				populationList=args;
				
				var cnt=[];
				
				for(var i=0;i<17;i++){
					cnt.push(0);
				}
				
				for(var i=0;i<args.length;i++){
					var platform = args[i].platform;
					if(platform=='3DS'){
						cnt[0]=cnt[0]+1;
					}else if(platform=='DC'){
						cnt[1]=cnt[1]+1;
					}else if(platform=='DS'){
						cnt[2]=cnt[2]+1;
					}else if(platform=='GBA'){
						cnt[3]=cnt[3]+1;
					}else if(platform=='GC'){
						cnt[4]=cnt[4]+1;
					}else if(platform=='PC'){
						cnt[5]=cnt[5]+1;
					}else if(platform=='PS'){
						cnt[6]=cnt[6]+1;
					}else if(platform=='PS2'){
						cnt[7]=cnt[7]+1;
					}else if(platform=='PS3'){
						cnt[8]=cnt[8]+1;
					}else if(platform=='PS4'){
						cnt[9]=cnt[9]+1;
					}else if(platform=='PSP'){
						cnt[10]=cnt[10]+1;
					}else if(platform=='PSV'){
						cnt[11]=cnt[11]+1;
					}else if(platform=='Wii'){
						cnt[12]=cnt[12]+1;
					}else if(platform=='WiiU'){
						cnt[13]=cnt[13]+1;
					}else if(platform=='X360'){
						cnt[14]=cnt[14]+1;
					}else if(platform=='XB'){
						cnt[15]=cnt[15]+1;
					}else{
						cnt[16]=cnt[16]+1;
					}
				}
				
				for(var i=0;i<17;i++){
					cnt[i]=cnt[i]*100;
					console.log(cnt[i]);
				}
				
				
				
				dataset={
					"children":[
						{"Name":"PS2","Count":cnt[7]},
						{"Name":"X360","Count":cnt[14]},
						{"Name":"PS3","Count":cnt[8]},
						{"Name":"PC","Count":cnt[5]},
						{"Name":"XB","Count":cnt[15]},
						{"Name":"Wii","Count":cnt[12]},
						{"Name":"DC","Count":cnt[1]},
						{"Name":"PSP","Count":cnt[10]},
						{"Name":"GC","Count":cnt[4]},
						{"Name":"PS4","Count":cnt[9]},
						{"Name":"GBA","Count":cnt[3]},
						{"Name":"Xone","Count":cnt[16]},
						{"Name":"3DS","Count":cnt[0]},
						{"Name":"PS","Count":cnt[6]},
						{"Name":"PSV","Count":cnt[11]},
						{"Name":"WiiU","Count":cnt[13]},
						{"Name":"DS","Count":cnt[2]}
						
					]	
				};
				
				
				var diameter = 430;
		        

		        var bubble = d3.pack(dataset)
		            .size([diameter, diameter])
		            .padding(1.5);

		        var svg = d3.select("#en1")
		            .append("svg")
		            .attr("width", diameter)
		            .attr("height", diameter)
		            .attr("class", "bubble");

		        var nodes = d3.hierarchy(dataset)
		            .sum(function(d) { return d.Count; });

		        var node = svg.selectAll(".node")
		            .data(bubble(nodes).descendants())
		            .enter()
		            .filter(function(d){
		                return  !d.children
		            })
		            .append("g")
		            .attr("class", "node")
		            .attr("transform", function(d) {
		                return "translate(" + d.x + "," + d.y + ")";
		            });

		        node.append("title")
		            .text(function(d) {
		                return d.Name + ": " + d.Count;
		            });

		        var color = d3.scaleOrdinal(d3.schemeCategory20);
		        
		        node.append("circle")
		            .attr("r", function(d) {
		                return d.r;
		            })
		            .style("fill", function(d,i) {
		                return color(i);
		            });

		        node.append("text")
		            .attr("dy", ".2em")
		            .style("text-anchor", "middle")
		            .text(function(d) {
		                return d.data.Name.substring(0, d.r / 3);
		            })
		            .attr("font-family", "sans-serif")
		            .attr("font-size", function(d){
		                return d.r/5;
		            })
		            .attr("fill", "white");

		        node.append("text")
		            .attr("dy", "1.3em")
		            .style("text-anchor", "middle")
		            .text(function(d) {
		                return d.data.Count;
		            })
		            .attr("font-family",  "Gill Sans", "Gill Sans MT")
		            .attr("font-size", function(d){
		                return d.r/5;
		            })
		            .attr("fill", "white");

		        d3.select(self.frameElement)
		            .style("height", diameter + "px");

		        var color = d3.scaleOrdinal(d3.schemeCategory20);

		    	var bubble = d3.pack(dataset)
		    	            .size([diameter, diameter])
		    	            .padding(1.5);

		    	var node = svg.selectAll(".node")
		    	            .data(bubble(nodes).descendants())
		    	            .enter()
		    	            .filter(function(d){
		    	                return  !d.children
		    	            })
		    	            .append("g")
		    	            .attr("class", "node")
		    	            .attr("transform", function(d) {
		    	                return "translate(" + d.x + "," + d.y + ")";
		    	            });
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				var cnt=[];  //NA,EU,JP,Other
				for(var i=0;i<5;i++){
					cnt.push(0);
				}
				
				
				for(var i=0;i<args.length;i++){
					var NA_Sales=args[i].na_Sales;
					var Other_Sales=args[i].other_sales;
					var EU_Sales=args[i].eu_Sales;
					var JP_Sales=args[i].jp_Sales;
					var Global_Sales=args[i].global_Sales;
					
					cnt[0]=cnt[0]+NA_Sales;
					cnt[1]=cnt[1]+Other_Sales;
					cnt[2]=cnt[2]+EU_Sales;
					cnt[3]=cnt[3]+JP_Sales;
					cnt[4]=cnt[4]+Global_Sales;
					
				}
				
				
				for(var i=0;i<4;i++){
					cnt[i]=Math.floor(cnt[i])*100;
					console.log(cnt[i]);
				}
				gl_tot=((Math.floor(cnt[4])-2)*100)-100;
				console.log(gl_tot);
				
				var width = 400;
				var height = 400;
				
				for(var i=0;i<4;i++){
					cnt[i]=Math.round((cnt[i]/gl_tot)*100);
				}
				
				
				const data = [
					  {name: 'NA', value: cnt[0], color: '#efa86b'},
					  {name: 'EU', value: cnt[1], color: '#f8d690'},
					  {name: 'JP', value: cnt[2], color: '#f8d690'},
					  {name: 'Other', value: cnt[3], color: '#f8d690'}
					];
				
				const arc = d3.arc().innerRadius(50).outerRadius(Math.min(width, height) / 2);
				// .arc() 새로운 기본값의 아치(호) 생성
				// .innerRadius() 안쪽 반지름 값, 0이면 완전한 원이되고 값이 있으면 도넛 형태가 됩니다.
				// .outerRadius() 바깥쪽 반지름값
				 
				const arcLabel = (() => {
				  const radius = Math.min(width, height) / 2 * 0.8;
				  return d3.arc().innerRadius(radius).outerRadius(radius);
				})();
				// 라벨이 위치할 반지름 값을 설정합니다.
				 
				const pie = d3.pie()
				  // 새로운 기본값의 파이 모양의 생성
				  .sort((a, b) => b.value - a.value)
				  // data의 value 큰값 > 작은값 순으로 정렬합니다. ex. 반대 순서는 a.value - b.value
				  .value(d => d.value);
				 
				const arcs = pie(data);
				 
				svg = d3.select('#pch').append('svg').style('width', width).style('height', height)
				  .attr('text-anchor', 'middle')
				  // text-anchor 텍스트의 정렬을 설정합니다 ( start | middle | end | inherit )
				  .style('font-size', '12px sans-serif');
				 
				const g = svg.append('g')
				  .attr('transform', `translate(${width/2}, ${height/2})`);
				  // 우선 차트를 그릴 그룹 엘리먼트를 추가합니다.
				  // 위치값을 각각 2로 나누는건 반지름 값을 기준으로 한바퀴 돌며 path를 그리기 때문인거 같습니다.
				 
				var color = d3.scaleOrdinal(d3.schemeCategory20);
				
				g.selectAll('path')
				  .data(arcs)
				  .enter().append('path').attr('fill', function(d,i) {
		                return color(i);
		            })
				  // 이전과 동일하게 가상 path 요소를 만들고 그래프 데이터와 매핑하여 엘리먼트를 추가합니다.
				    /*.attr('fill', d => d.data.color)*/
				    // 다른 그래프와 다르게 .data 라는 객체가 추가되어 있는데, 위에 arcs 변수를 선언할때
				    // .pie(data)가 {data, value, index, startAngle, endAngle, padAngle} 의 값을 가지고 있습니다.
				    .attr('stroke', function(d,i) {
		                return color(i);
		            })
				    .attr('d', arc)
				  .append('title')
				    .text(d => `${d.data.name}: ${d.data.value}`);
				    // 각각 페스의 자식으로 title의 엘리먼트에 텍스트로 출력합니다.
				    // 실제로 뷰에 출력되지는 않지만 시멘틱하게 각각의 요소의 설명 문자열을 제공합니다.
				 
				const text = g.selectAll('text')
				  .data(arcs)
				  .enter().append('text')
				    .attr('transform', d => `translate(${arcLabel.centroid(d)})`)
				    .attr('dy', '0.35em');
				  // 라벨을 취가하기 위한 text 엘리먼트를 만들고 위치를 지정합니다.
				 
				text.append('tspan')
				  .attr('x', 0)
				  .attr('y', '-0.7em')
				  .style('font-weight', 'bold')
				  .style('font-size',18)
				  .text(d => d.data.name)
				  // 해당 데이터 항목의 이름을 두꺼운 글씨로 출력합니다. ex. A
				 
				text.filter(d => (d.endAngle - d.startAngle > 0.25)).append('tspan')
				  .attr('x', 0)
				  .attr('y', '0.7em')
				  .attr('fill-opacity', 0.7)
				  .style('font-weight', 'bold')
				  .style('font-size',18)
				  .text(d => d.data.value+"%");
				  // 해당 데이터의 수치값을 투명도를 주어 출력합니다. ex. 1000
				 
				svg.node();
				
				
				
			}
		});

url="/data/Year_Avg";
$.ajax({
	type:"POST",
	url:url,
	success:function(args){
		var year=[];
		for(var i=0;i<8;i++){
			year.push(0);
		}
		var cnt=0;
		for(var i=0;i<args.length;i++){
			var developer= args[i].developer;
			var avg=args[i].avg;
			
			if(developer=='id Software'){
				year[cnt]=avg;
				cnt++;
			}
		}
		
		
		var margin = {top: 50, right: 50, bottom: 50, left: 50}
		  , width = 430 - margin.left - margin.right // Use the window's width 
		  , height = 430 - margin.top - margin.bottom; // Use the window's height

		// The number of datapoints
		var n = 21;

		// 5. X scale will use the index of our data
		var xScale = d3.scaleLinear()
		    .domain([1985, 2000]) // input
		    .range([0, width]); // output

		// 6. Y scale will use the randomly generate number 
		var yScale = d3.scaleLinear()
		    .domain([0, 10]) // input 
		    .range([height, 0]); // output 

		// 7. d3's line generator
		var line = d3.line()
		    .x(function(d, i) { return xScale(i); }) // set the x values for the line generator
		    .y(function(d) { return yScale(d.y); }) // set the y values for the line generator 
		    .curve(d3.curveBasis) // apply smoothing to the line

		// 8. An array of objects of length N. Each object has key -> value pair, the key being "y" and the value is a random number
		var dataset = [{'y':year[0]},{'y':year[1]},{'y':year[2]},{'y':year[3]},{'y':year[4]},{'y':year[5]},{'y':year[6]},{'y':year[7]}] //d3.range(n).map(function(d) { return {"y": d3.randomUniform(1)() } })

		// 1. Add the SVG to the page and employ #2
		var svg = d3.select("#em3").append("svg")
		    .attr("width", width + margin.left + margin.right)
		    .attr("height", height + margin.top + margin.bottom)
		  .append("g")
		    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

		// 3. Call the x axis in a group tag
		svg.append("g")
		    .attr("class", "x axis")
		    .attr("transform", "translate(0," + height + ")")
		    .call(d3.axisBottom(xScale)); // Create an axis component with d3.axisBottom

		// 4. Call the y axis in a group tag
		svg.append("g")
		    .attr("class", "y axis")
		    .call(d3.axisLeft(yScale)); // Create an axis component with d3.axisLeft

		// 9. Append the path, bind the data, and call the line generator 
		svg.append("path")
		    .datum(dataset) // 10. Binds data to the line 
		    .attr("class", "line") // Assign a class for styling 
		    .attr("d", line); // 11. Calls the line generator 

		// 12. Appends a circle for each datapoint 
		svg.selectAll(".dot")
		    .data(dataset)
		  .enter().append("circle") // Uses the enter().append() method
		    .attr("class", "dot") // Assign a class for styling
		    .attr("cx", function(d, i) { return xScale(i+1986) })
		    .attr("cy", function(d) { return yScale(d.y) })
		    .attr("r", 5);
		console.log("year: "+year);
	}
});
/*$(document).ready(function() {
    load_bubble();
});



function load_bubble(){
	var populationList;
	
	$("#load_bubble").click(function(){
		var url="/data/Vgsales";
		$.ajax({
			type:"POST",
			url:url,
			success:function(args){
				populationList=args;
				
				var cnt=[];
				
				for(var i=0;i<17;i++){
					cnt.push(0);
				}
				
				for(var i=0;i<args.length;i++){
					var platform = args[i].platform;
					if(platform=='3DS'){
						cnt[0]=cnt[0]+1;
					}else if(platform=='DC'){
						cnt[1]=cnt[1]+1;
					}else if(platform=='DS'){
						cnt[2]=cnt[2]+1;
					}else if(platform=='GBA'){
						cnt[3]=cnt[3]+1;
					}else if(platform=='GC'){
						cnt[4]=cnt[4]+1;
					}else if(platform=='PC'){
						cnt[5]=cnt[5]+1;
					}else if(platform=='PS'){
						cnt[6]=cnt[6]+1;
					}else if(platform=='PS2'){
						cnt[7]=cnt[7]+1;
					}else if(platform=='PS3'){
						cnt[8]=cnt[8]+1;
					}else if(platform=='PS4'){
						cnt[9]=cnt[9]+1;
					}else if(platform=='PSP'){
						cnt[10]=cnt[10]+1;
					}else if(platform=='PSV'){
						cnt[11]=cnt[11]+1;
					}else if(platform=='Wii'){
						cnt[12]=cnt[12]+1;
					}else if(platform=='WiiU'){
						cnt[13]=cnt[13]+1;
					}else if(platform=='X360'){
						cnt[14]=cnt[14]+1;
					}else if(platform=='XB'){
						cnt[15]=cnt[15]+1;
					}else{
						cnt[16]=cnt[16]+1;
					}
				}
				
				for(var i=0;i<17;i++){
					cnt[i]=cnt[i]*100;
					console.log(cnt[i]);
				}
				
				
				
				dataset={
					"children":[
						{"Name":"PS2","Count":cnt[7]},
						{"Name":"X360","Count":cnt[14]},
						{"Name":"PS3","Count":cnt[8]},
						{"Name":"PC","Count":cnt[5]},
						{"Name":"XB","Count":cnt[15]},
						{"Name":"Wii","Count":cnt[12]},
						{"Name":"DC","Count":cnt[1]},
						{"Name":"PSP","Count":cnt[10]},
						{"Name":"GC","Count":cnt[4]},
						{"Name":"PS4","Count":cnt[9]},
						{"Name":"GBA","Count":cnt[3]},
						{"Name":"Xone","Count":cnt[16]},
						{"Name":"3DS","Count":cnt[0]},
						{"Name":"PS","Count":cnt[6]},
						{"Name":"PSV","Count":cnt[11]},
						{"Name":"WiiU","Count":cnt[13]},
						{"Name":"DS","Count":cnt[2]}
						
					]	
				};
				
				
				var diameter = 430;
		        var color = d3.scaleOrdinal(d3.schemeCategory20);

		        var bubble = d3.pack(dataset)
		            .size([diameter, diameter])
		            .padding(1.5);

		        var svg = d3.select("#my_dataviz")
		            .append("svg")
		            .attr("width", diameter)
		            .attr("height", diameter)
		            .attr("class", "bubble");

		        var nodes = d3.hierarchy(dataset)
		            .sum(function(d) { return d.Count; });

		        var node = svg.selectAll(".node")
		            .data(bubble(nodes).descendants())
		            .enter()
		            .filter(function(d){
		                return  !d.children
		            })
		            .append("g")
		            .attr("class", "node")
		            .attr("transform", function(d) {
		                return "translate(" + d.x + "," + d.y + ")";
		            });

		        node.append("title")
		            .text(function(d) {
		                return d.Name + ": " + d.Count;
		            });

		        node.append("circle")
		            .attr("r", function(d) {
		                return d.r;
		            })
		            .style("fill", function(d,i) {
		                return color(i);
		            });

		        node.append("text")
		            .attr("dy", ".2em")
		            .style("text-anchor", "middle")
		            .text(function(d) {
		                return d.data.Name.substring(0, d.r / 3);
		            })
		            .attr("font-family", "sans-serif")
		            .attr("font-size", function(d){
		                return d.r/5;
		            })
		            .attr("fill", "white");

		        node.append("text")
		            .attr("dy", "1.3em")
		            .style("text-anchor", "middle")
		            .text(function(d) {
		                return d.data.Count;
		            })
		            .attr("font-family",  "Gill Sans", "Gill Sans MT")
		            .attr("font-size", function(d){
		                return d.r/5;
		            })
		            .attr("fill", "white");

		        d3.select(self.frameElement)
		            .style("height", diameter + "px");

		        var color = d3.scaleOrdinal(d3.schemeCategory20);

		    	var bubble = d3.pack(dataset)
		    	            .size([diameter, diameter])
		    	            .padding(1.5);

		    	var node = svg.selectAll(".node")
		    	            .data(bubble(nodes).descendants())
		    	            .enter()
		    	            .filter(function(d){
		    	                return  !d.children
		    	            })
		    	            .append("g")
		    	            .attr("class", "node")
		    	            .attr("transform", function(d) {
		    	                return "translate(" + d.x + "," + d.y + ")";
		    	            });
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				var cnt=[];  //NA,EU,JP,Other
				for(var i=0;i<5;i++){
					cnt.push(0);
				}
				
				
				for(var i=0;i<args.length;i++){
					var NA_Sales=args[i].na_Sales;
					var Other_Sales=args[i].other_sales;
					var EU_Sales=args[i].eu_Sales;
					var JP_Sales=args[i].jp_Sales;
					var Global_Sales=args[i].global_Sales;
					
					cnt[0]=cnt[0]+NA_Sales;
					cnt[1]=cnt[1]+Other_Sales;
					cnt[2]=cnt[2]+EU_Sales;
					cnt[3]=cnt[3]+JP_Sales;
					cnt[4]=cnt[4]+Global_Sales;
					
				}
				
				
				for(var i=0;i<4;i++){
					cnt[i]=Math.floor(cnt[i])*100;
					console.log(cnt[i]);
				}
				gl_tot=((Math.floor(cnt[4])-2)*100)-100;
				console.log(gl_tot);
				
				const width = 500;
				const height = 500;
				
				for(var i=0;i<4;i++){
					cnt[i]=Math.round((cnt[i]/gl_tot)*100);
				}
				
				
				const data = [
					  {name: 'NA', value: cnt[0], color: '#efa86b'},
					  {name: 'EU', value: cnt[1], color: '#f8d690'},
					  {name: 'JP', value: cnt[2], color: '#f8d690'},
					  {name: 'Other', value: cnt[3], color: '#f8d690'}
					];
				
				const arc = d3.arc().innerRadius(50).outerRadius(Math.min(width, height) / 2);
				// .arc() 새로운 기본값의 아치(호) 생성
				// .innerRadius() 안쪽 반지름 값, 0이면 완전한 원이되고 값이 있으면 도넛 형태가 됩니다.
				// .outerRadius() 바깥쪽 반지름값
				 
				const arcLabel = (() => {
				  const radius = Math.min(width, height) / 2 * 0.8;
				  return d3.arc().innerRadius(radius).outerRadius(radius);
				})();
				// 라벨이 위치할 반지름 값을 설정합니다.
				 
				const pie = d3.pie()
				  // 새로운 기본값의 파이 모양의 생성
				  .sort((a, b) => b.value - a.value)
				  // data의 value 큰값 > 작은값 순으로 정렬합니다. ex. 반대 순서는 a.value - b.value
				  .value(d => d.value);
				 
				const arcs = pie(data);
				 
				svg = d3.select('#em1').append('svg').style('width', width).style('height', height)
				  .attr('text-anchor', 'middle')
				  // text-anchor 텍스트의 정렬을 설정합니다 ( start | middle | end | inherit )
				  .style('font-size', '12px sans-serif');
				 
				const g = svg.append('g')
				  .attr('transform', `translate(${width/2}, ${height/2})`);
				  // 우선 차트를 그릴 그룹 엘리먼트를 추가합니다.
				  // 위치값을 각각 2로 나누는건 반지름 값을 기준으로 한바퀴 돌며 path를 그리기 때문인거 같습니다.
				 
				g.selectAll('path')
				  .data(arcs)
				  .enter().append('path')
				  // 이전과 동일하게 가상 path 요소를 만들고 그래프 데이터와 매핑하여 엘리먼트를 추가합니다.
				    .attr('fill', d => d.data.color)
				    // 다른 그래프와 다르게 .data 라는 객체가 추가되어 있는데, 위에 arcs 변수를 선언할때
				    // .pie(data)가 {data, value, index, startAngle, endAngle, padAngle} 의 값을 가지고 있습니다.
				    .attr('stroke', 'white')
				    .attr('d', arc)
				  .append('title')
				    .text(d => `${d.data.name}: ${d.data.value}`);
				    // 각각 페스의 자식으로 title의 엘리먼트에 텍스트로 출력합니다.
				    // 실제로 뷰에 출력되지는 않지만 시멘틱하게 각각의 요소의 설명 문자열을 제공합니다.
				 
				const text = g.selectAll('text')
				  .data(arcs)
				  .enter().append('text')
				    .attr('transform', d => `translate(${arcLabel.centroid(d)})`)
				    .attr('dy', '0.35em');
				  // 라벨을 취가하기 위한 text 엘리먼트를 만들고 위치를 지정합니다.
				 
				text.append('tspan')
				  .attr('x', 0)
				  .attr('y', '-0.7em')
				  .style('font-weight', 'bold')
				  .text(d => d.data.name)
				  // 해당 데이터 항목의 이름을 두꺼운 글씨로 출력합니다. ex. A
				 
				text.filter(d => (d.endAngle - d.startAngle > 0.25)).append('tspan')
				  .attr('x', 0)
				  .attr('y', '0.7em')
				  .attr('fill-opacity', 0.7)
				  .text(d => d.data.value+"%");
				  // 해당 데이터의 수치값을 투명도를 주어 출력합니다. ex. 1000
				 
				svg.node();
			}
		});
		
	});
}
*/

$(function() {
	
    $('#download').click(function(){
    	var filePath = "/resources/download/video_games_sales.csv";
    	var filePath = encodeURI(filePath);
    	var fileName = "데이터.csv";
    				
    	location.href = "/data/contract/fileDownload?filePath="+filePath+"&fileName="+fileName;
    })
	
});