
////////////////// xxx 그래프 /////////////////////////
//Graph dimension
var margin = {top: 35, right: 35, bottom: 35, left: 35},
    width = 500 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom

// Create the svg area

// ajax로 데이터 가져오기
var url="/data/video"; // 데이터 가져오는 경로
console.log(url); // 경로 확인
var videoList;

$.ajax({      
    type:"POST",  
    url:url,      
         
    success:function(args){
        //console.log(args);
        videoList = args;
     
        /*for(i=0;i<16;i++){
    		cnt.push[0];
    	}*/
        var cnt=[0];
        var cnt1=[0];
        var cnt2=[0];
        var cnt3=[0];
        var cnt4=[0];
        var cnt5=[0];
        var cnt6=[0];
        var cnt7=[0];
        var cnt8=[0];
        var cnt9=[0];
        var cnt10=[0];
        var cnt11=[0];
        var cnt12=[0];
        var cnt13=[0];
        var cnt14=[0];
        var cnt15=[0];
        var cnt16=[0];
 
        
        for(var i=0; i<args.length; i++){
        	
        	var platform = args[i].platform;
        	var yor = args[i].year_of_Release;
        	var glb=args[i].global_Sales;
        	var uc = args[i].user_Count;
        	var Gen = args[i].genre;
        	
        	
        	if(args[i].platform=='3DS'){
        		cnt[0]=cnt[0]+args[i].user_Count;
        	}
        	if(args[i].platform=='DC'){
        		cnt1[0]=cnt1[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='DS'){
        		cnt2[0]=cnt2[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='GBA'){
        		cnt3[0]=cnt3[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='GC'){
        		cnt4[0]=cnt4[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PC'){
        		cnt5[0]=cnt5[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PS'){
        		cnt6[0]=cnt6[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PS2'){
        		cnt7[0]=cnt7[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PS3'){
        		cnt8[0]=cnt8[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PS4'){
        		cnt9[0]=cnt9[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PSP'){
        		cnt10[0]=cnt10[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='PSV'){
        		cnt11[0]=cnt11[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='Wii'){
        		cnt12[0]=cnt12[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='WiiU'){
        		cnt13[0]=cnt13[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='X360'){
        		cnt14[0]=cnt14[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='XB'){
        		cnt15[0]=cnt15[0]+args[i].user_Count;
        	}
        	else if(args[i].platform=='XOne'){
        		cnt16[0]=cnt16[0]+args[i].user_Count;
        	}
        	
        	
        	
        	
        	
        	
        
    
        
        }
        
        console.log(cnt[0]);
        console.log(cnt1[0]);
        console.log(cnt2[0]);
        console.log(cnt3[0]);
        console.log(cnt4[0]);
        console.log(cnt5[0]);
        console.log(cnt6[0]);
        console.log(cnt7[0]);
        console.log(cnt8[0]);
        console.log(cnt9[0]);
        console.log(cnt10[0]);
        console.log(cnt11[0]);
        console.log(cnt12[0]);
        console.log(cnt13[0]);
        console.log(cnt14[0]);
        console.log(cnt15[0]);
        console.log(cnt16[0]);
      
        
    
       
        
      //Width and height
        var width = 600;
        var barPadding = 1;
        
        
        
        
        
        /*var dataset = [ Math.floor(cnt12[0]/10), Math.floor(cnt1[0]/10),Math.floor(cnt2[0]/10),
        	Math.floor(cnt3[0]/10),Math.floor(cnt4[0]/10),Math.floor(cnt5[0]/10),Math.floor(cnt13[0]/10),
        	Math.floor(cnt14[0]/10),Math.floor(cnt15[0]/10),Math.floor(cnt11[0]/10),Math.floor(cnt9[0]/10)
        	
            ];*/
        
       
      
 
        
       
        /*dataset = {
                "children": [
                	{"Name":"3DS","Count":Math.floor(cnt[0]/10)},
                	{"Name":"DC ","Count":Math.floor(cnt1[0]/10)},
                	{"Name":"DS ","Count":Math.floor(cnt2[0]/10)},
                	{"Name":"GBA ","Count":Math.floor(cnt3[0]/10)},
                	{"Name":"GC","Count":Math.floor(cnt4[0]/10)},
                	{"Name":"PC ","Count":Math.floor(cnt5[0]/10)},
                	{"Name":"PS ","Count":Math.floor(cnt6[0]/10)},
                	{"Name":"PS2","Count":Math.floor(cnt7[0]/10)},
                	{"Name":"PS3 ","Count":Math.floor(cnt8[0]/10)},
                	{"Name":"PS4","Count":Math.floor(cnt9[0]/10)},
                	{"Name":"PSP ","Count":Math.floor(cnt10[0]/10)},
                	{"Name":"PSV","Count":Math.floor(cnt1[0]/10)},
                	{"Name":"Wii","Count":Math.floor(cnt12[0]/10)},
                	{"Name":"WiiU","Count":Math.floor(cnt13[0]/10)},
                	{"Name":"X360","Count":Math.floor(cnt14[0]/10)},
                	{"Name":"XB","Count":Math.floor(cnt15[0]/10)},
                	{"Name":"XOne","Count":Math.floor(cnt16[0]/10)}
                	
                    ]
            };*/
        
        dataset = {
                "children": [
                	{"Name":"PC ","Count":cnt5[0]},
                	{"Name":"X360","Count":cnt14[0]},
                	{"Name":"PS3 ","Count":cnt8[0]},
                	{"Name":"PS4","Count":cnt9[0]},
                	{"Name":"PS2","Count":cnt7[0]},  
                	{"Name":"XOne","Count":cnt16[0]},
                	{"Name":"Wii","Count":cnt12[0]},
                	{"Name":"WiiU","Count":cnt13[0]},
                	{"Name":"3DS","Count":cnt[0]},
                	{"Name":"DS ","Count":cnt2[0]},
                	{"Name":"XB","Count":cnt15[0]},
                	{"Name":"PSV","Count":cnt1[0]},
                	{"Name":"GC","Count":cnt4[0]},
                	{"Name":"PSP ","Count":cnt10[0]},
                	{"Name":"PS ","Count":cnt6[0]},
                	{"Name":"GBA ","Count":cnt3[0]},
                	{"Name":"DC ","Count":cnt1[0]},
                	
                	
             
                    ]
            };
        
        
          
/*        
         //3DS  15852
           DC   1183
        // DS   14005
         GBA    5725
         //GC   12959
         //PC   455091
         PS   	11587
         //PS2  52500
         //PS3  174940
        // PS4  132267
         //PSP  12525
        // PSV  13195
         //Wii  28888
         //WiiU 22217
         //X360 175080
         //XB   13858
         //XOne 50608
*/        // 버블차트
    	console.log(dataset);
    	
            var diameter = 400;
            var color = d3.scaleOrdinal(d3.schemeCategory20);

            var bubble = d3.pack(dataset)
                .size([diameter, diameter])
                .padding(1.5);

            var svg = d3.select("#hjh")
                .append("svg")
                .attr("width", diameter)
                .attr("height", diameter)
                .attr("class", "bubble");

            var nodes = d3.hierarchy(dataset)
                .sum(function(d) { return d.Count; });

            var node = svg.selectAll(".node")
                .data(bubble(nodes).descendants())
                .enter()
                .filter(function(d){
                    return  !d.children
                })
                .append("g")
                .attr("class", "node")
                .attr("transform", function(d) {
                    return "translate(" + d.x + "," + d.y + ")";
                });

            node.append("title")
                .text(function(d) {
                    return d.Name + ": " + d.Count ;
                });

            node.append("circle")
                .attr("r", function(d) {
                    return d.r;
                })
                .style("fill", function(d,i) {
                    return color(i);
                });

            node.append("text")
                .attr("dy", ".2em")
                .style("text-anchor", "middle")
                .text(function(d) {
                    return d.data.Name.substring(0, d.r / 3);
                   
                })
                .attr("font-family", "sans-serif")
                .attr("font-size", function(d){
                    return d.r/2;
                })
                .attr("fill", "white");

            node.append("text")
                .attr("dy", "1.3em")
                .style("text-anchor", "middle")
                .text(function(d) {
                    return d.data.Count;
                })
                .attr("font-family",  "Gill Sans", "Gill Sans MT")
                .attr("font-size", function(d){
                    return d.r/3;
                })
                .attr("fill", "white");

            d3.select(self.frameElement)
                .style("height", diameter + "px");

            var color = d3.scaleOrdinal(d3.schemeCategory20);

        	var bubble = d3.pack(dataset)
        	            .size([diameter, diameter])
        	            .padding(1.5);

        	var node = svg.selectAll(".node")
        	            .data(bubble(nodes).descendants())
        	            .enter()
        	            .filter(function(d){
        	                return  !d.children
        	            })
        	            .append("g")
        	            .attr("class", "node")
        	            .attr("transform", function(d) {
        	                return "translate(" + d.x + "," + d.y + ")";
        	            });
    	
        
        /* //막대 그래프
           //Create SVG element
           var svg = d3.select("#my_dataviz2")
                       .append("svg")
                       .attr("width", width)
						.attr("height", height);

           
           
           svg.selectAll("rect")
              .data(dataset)
              .enter()
              .append("rect")
              .attr("x", function(d, i) {

                      return i*(width/dataset.length);

              })

              .attr("y", function(d) {
                      return height - (d * 4);
              })
              .attr("width", width / dataset.length - barPadding)
              .attr("height", function(d) {
                 	   return d * 4;
              })
              .attr("fill", function(d) {
                   return "rgb(0, 0, " + (d * 10) + ")";
            	  return "rgb(" + (d * 10) + ",0,0 )";
              });


           svg.selectAll("text")
              .data(dataset)
              .enter()
              .append("text")
              .text(function(d) {
           	   return d * 10;
              })

              .attr("text-anchor", "middle")

              .attr("x", function(d, i) {
                      return i * (width/dataset.length) + (width/dataset.length - barPadding)/2;

              })
              .attr("y", function(d) {
                      return height - (d * 4) + 14;

              })
              .attr("font-family", "sans-serif")
              .attr("font-size", "11px")
              .attr("fill", "white"); */
           
       
    }

});