/*var margin = {top: 35, right: 35, bottom: 35, left: 35},
width = 400 - margin.left - margin.right,
height = 400 - margin.top - margin.bottom


var url="/data/video";   
var videoList;

$.ajax({      
    type:"POST",  
    url:url,
    success:function(args){
       videoList = args;
       
       // 그래프에 그리는 데이터 생성
    

var keys = d3.keys(dataset[0]);
var data = [];
for(var i=0;i<args.length;i++){
   var y = args[i].action;
   var y1 = args[i].adventure;
   var y2 = args[i].fighting;
   var y3 = args[i].misc;
   var y4 = args[i].platform;
   var y5 = args[i].puzzle;
   var y6 = args[i].racing;
   var y7 = args[i].role-Playing;
   var y8 = args[i].shooter;
   var y9 = args[i].simulation;
   var y10 = args[i].sports;
   var y11 = args[i].strategy;
   data.push({
      y:y,
      y1:y1,
      y2:y2,
      y3:y3,
      y4:y4,
      y5:y5,
      y6:y6,
      y7:y7,
      y8:y8,
      y9:y9,
      y10:y10,
      y11:y11
      });
}
console.log(data);
dataset.forEach(function(d, i) {
       data[i] = keys.map(function(key) { return {x: key, y: d[key]}; })
});



var width  = parseInt(svg.style("width"), 10) - margin.left - margin.right;
var height = parseInt(svg.style("height"), 10)- margin.top  - margin.bottom;

var svgG = svg.append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

var xScale = d3.scalePoint()//scaleBand() scaleOrdinal
    .domain(keys)
    .rangeRound([0, width]);

var yScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, function(d) { return d3.max(keys, function(key) { return d[key];});})])
    .nice()
    .range([height, 0]);

var colors = d3.scaleOrdinal(d3.schemeCategory20);

var svg = d3.select("#pdj")
.append("svg")
.attr("width", width + margin.left + margin.right)
.attr("height", height + margin.top + margin.bottom)
.append("g")
.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

   svg.append("g")
    .attr("class", "grid")
    .attr("transform", "translate(0," + height + ")")
    .call(d3.axisBottom(xScale)
        .tickSize(-height)
    );

   svg.append("g")
    .attr("class", "grid")
    .call(d3.axisLeft(yScale)
        .ticks(5)
        .tickSize(-width)
    );

var line = d3.line()
       .curve(d3.curveBasis)
    .x(function(d) { return xScale(d.x); })
    .y(function(d) { return yScale(d.y); });

var lineG = svg.append("g")
    .selectAll("g")
       .data(data)
    .enter().append("g");

lineG.append("path")
    .attr("class", "lineChart")
    .style("stroke", function(d, i) { return colors( series[i]); })
    .attr("d", line);

var legend = svg.append("g")
    .attr("text-anchor", "end")
    .selectAll("g")
    .data(series)
    .enter().append("g")
    .attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });

legend.append("rect")
    .attr("x", width - 20)
    .attr("width", 19)
    .attr("height", 19)
    .attr("fill", colors);

legend.append("text")
    .attr("x", width - 30)
    .attr("y", 9.5)
    .attr("dy", "0.32em")
    .text(function(d) { return d; });
var margin = {top: 50, right: 50, bottom: 50, left: 50},
    width = 400 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom
    


 

 

// ajax로 데이터 가져오기

var url="/data/video";   

var videoList;

 

$.ajax({      

    type:"POST",  

    url:url,

    success:function(args){

       videoList = args;

       

       // 그래프에 그리는 데이터 생성

       var data = [];

       for(var i=0;i<args.length;i++){

          var x = args[i].critic_Score;

          var y = args[i].user_Score;

          data.push({

             x:x,

             y:y,

          });

        }
console.log(data);
       

       // Add X axis
var svg = d3.select("#pdj")
.append("svg")
  .attr("width", width + margin.left + margin.right)
  .attr("height", height + margin.top + margin.bottom)
.append("g")
  .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

         var x = d3.scaleLinear()

           .domain([0, 10])

           .range([ 0, width ]);

         svg.append("g")

           .attr("transform", "translate(0," + height + ")")

           .call(d3.axisBottom(x));

 

         // Add Y axis

         var y = d3.scaleLinear()

           .domain([0, 10])

           .range([ height, 0]);

         svg.append("g")

           .call(d3.axisLeft(y));

 

         // Add dots

         svg.append('g')

           .selectAll("dot")

           .data(data)

           .enter()

           .append("circle")

             .attr("cx", function (d) { return x(d.x); } )

             .attr("cy", function (d) { return y(d.y); } )

             .attr("r", 0.5)

             .style("fill", "#69b3a2")

       

    }

});
*/

var margin = {top: 20, right: 10, bottom: 10, left: 50},
    width = 400 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom

// Create the svg area

// ajax로 데이터 가져오기
var url="/data/video"; // 데이터 가져오는 경로
console.log(url); // 경로 확인
var videoList;
$.ajax({      
    type:"POST",  
    url:url,      
             
    success:function(args){


        videoList = args;
        var data = [];
        var total = [] ;
        var NAtotal = [];
        var EUtotal = [];
        var JPtotal = [];
        for(var i=0;i<10;i++){
           total.push(0);  // 12개 0 0 0 0 0 0 0 0 0 12개
           NAtotal.push(0);
           EUtotal.push(0);
           JPtotal.push(0);
        }
        for(var i=0;i<args.length;i++){
           var x = Object.keys(args[i])[i];
           
           
           if(1980<=args[i].year_of_Release&&args[i].year_of_Release<1985)
            {total[0] = total[0] + args[i].global_Sales}
           if(1985<=args[i].year_of_Release&&args[i].year_of_Release<1990)
            {total[1] = total[1] + args[i].global_Sales}
           if(1990<=args[i].year_of_Release&&args[i].year_of_Release<1995)
            {total[2] = total[2] + args[i].global_Sales}
           if(1995<=args[i].year_of_Release&&args[i].year_of_Release<2000)
            {total[3] = total[3] + args[i].global_Sales}
           if(2000<=args[i].year_of_Release&&args[i].year_of_Release<2005)
            {total[4] = total[4] + args[i].global_Sales}
           if(2005<=args[i].year_of_Release&&args[i].year_of_Release<2010)
            {total[5] = total[5] + args[i].global_Sales}
           if(2010<=args[i].year_of_Release&&args[i].year_of_Release<2015)
            {total[6] = total[6] + args[i].global_Sales}
           if(2015<=args[i].year_of_Release)
            {total[7] = total[7] + args[i].global_Sales}
           
           if(1980<=args[i].year_of_Release&&args[i].year_of_Release<1985)
            {NAtotal[0] = NAtotal[0] + args[i].na_Sales}
           if(1985<=args[i].year_of_Release&&args[i].year_of_Release<1990)
            {NAtotal[1] = NAtotal[1] + args[i].na_Sales}
           if(1990<=args[i].year_of_Release&&args[i].year_of_Release<1995)
            {NAtotal[2] = NAtotal[2] + args[i].na_Sales}
           if(1995<=args[i].year_of_Release&&args[i].year_of_Release<2000)
            {NAtotal[3] = NAtotal[3] + args[i].na_Sales}
           if(2000<=args[i].year_of_Release&&args[i].year_of_Release<2005)
            {NAtotal[4] = NAtotal[4] + args[i].na_Sales}
           if(2005<=args[i].year_of_Release&&args[i].year_of_Release<2010)
            {NAtotal[5] = NAtotal[5] + args[i].na_Sales}
           if(2010<=args[i].year_of_Release&&args[i].year_of_Release<2015)
            {NAtotal[6] = NAtotal[6] + args[i].na_Sales}
           if(2015<=args[i].year_of_Release)
            {NAtotal[7] = NAtotal[7] + args[i].na_Sales}

           if(1980<=args[i].year_of_Release&&args[i].year_of_Release<1985)
            {EUtotal[0] = EUtotal[0] + args[i].eu_Sales}
           if(1985<=args[i].year_of_Release&&args[i].year_of_Release<1990)
            {EUtotal[1] = EUtotal[1] + args[i].eu_Sales}
           if(1990<=args[i].year_of_Release&&args[i].year_of_Release<1995)
            {EUtotal[2] = EUtotal[2] + args[i].eu_Sales}
           if(1995<=args[i].year_of_Release&&args[i].year_of_Release<2000)
            {EUtotal[3] = EUtotal[3] + args[i].eu_Sales}
           if(2000<=args[i].year_of_Release&&args[i].year_of_Release<2005)
            {EUtotal[4] = EUtotal[4] + args[i].eu_Sales}
           if(2005<=args[i].year_of_Release&&args[i].year_of_Release<2010)
            {EUtotal[5] = EUtotal[5] + args[i].eu_Sales}
           if(2010<=args[i].year_of_Release&&args[i].year_of_Release<2015)
            {EUtotal[6] = EUtotal[6] + args[i].eu_Sales}
           if(2015<=args[i].year_of_Release)
            {EUtotal[7] = EUtotal[7] + args[i].eu_Sales}
           
           if(1980<=args[i].year_of_Release&&args[i].year_of_Release<1985)
            {JPtotal[0] = JPtotal[0] + args[i].jp_Sales}
           if(1985<=args[i].year_of_Release&&args[i].year_of_Release<1990)
            {JPtotal[1] = JPtotal[1] + args[i].jp_Sales}
           if(1990<=args[i].year_of_Release&&args[i].year_of_Release<1995)
            {JPtotal[2] = JPtotal[2] + args[i].jp_Sales}
           if(1995<=args[i].year_of_Release&&args[i].year_of_Release<2000)
            {JPtotal[3] = JPtotal[3] + args[i].jp_Sales}
           if(2000<=args[i].year_of_Release&&args[i].year_of_Release<2005)
            {JPtotal[4] = JPtotal[4] + args[i].jp_Sales}
           if(2005<=args[i].year_of_Release&&args[i].year_of_Release<2010)
            {JPtotal[5] = JPtotal[5] + args[i].jp_Sales}
           if(2010<=args[i].year_of_Release&&args[i].year_of_Release<2015)
            {JPtotal[6] = JPtotal[6] + args[i].jp_Sales}
           if(2015<=args[i].year_of_Release)
            {JPtotal[7] = JPtotal[7] + args[i].jp_Sales}
        }
        
            var series = ["Global_Sales","NA_Sales","EU_Sales","JP_Sales"];
         
            var dataset = [ 
                {'1980': total[0], '1985':total[1], '1990':total[2], '1995':total[3], '2000':total[4], '2005':total[5], '2010':total[6], '2015':total[7]*5},
                {'1980': NAtotal[0], '1985':NAtotal[1], '1990':NAtotal[2], '1995':NAtotal[3], '2000':NAtotal[4], '2005':NAtotal[5], '2010':NAtotal[6], '2015':NAtotal[7]*3},
                {'1980': EUtotal[0], '1985':EUtotal[1], '1990':EUtotal[2], '1995':EUtotal[3], '2000':EUtotal[4], '2005':EUtotal[5], '2010':EUtotal[6], '2015':EUtotal[7]*3},
                {'1980': JPtotal[0], '1985':JPtotal[1], '1990':JPtotal[2], '1995':JPtotal[3], '2000':JPtotal[4], '2005':JPtotal[5], '2010':JPtotal[6], '2015':JPtotal[7]*3}
                
                ];
         
            /*var dataset = [ 
                {'1980': 300, '1985':320, '1990':320, '1995':320, '2000':323, '2005':322, '2010':360, '2015':380},
                {'1980': 400, '1985':420, '1990':420, '1995':420, '2000':123, '2005':322, '2010':460, '2015':580},
                {'1980': 500, '1985':520, '1990':520, '1995':520, '2000':123, '2005':222, '2010':160, '2015':380}
                
                ];*/
            var keys = d3.keys(dataset[0]);
            var data = [];
         
            dataset.forEach(function(d, i) {
                   data[i] = keys.map(function(key) { return {x: key, y: d[key]}; })
            });
         
            
            
            var svg = d3.select("#pdj")
            .append("svg")
              .attr("width", width + margin.left + margin.right)
              .attr("height", height + margin.top + margin.bottom)
            .append("g")
              .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
           
            var width=300;
         
            var svgG = svg.append("g")
                .attr("transform", "translate(30,0)");
         
            var xScale = d3.scalePoint()//scaleBand() scaleOrdinal
                .domain(keys)
                .rangeRound([0, width]);
         
            var yScale = d3.scaleLinear()
                .domain([0, d3.max(dataset, function(d) { return d3.max(keys, function(key) { return d[key];});})])
                .nice()
                .range([height, 0]);
         
            var colors = d3.scaleOrdinal(d3.schemeCategory20);
         
            svgG.append("g")
                .attr("class", "grid")
                .attr("transform", "translate(0," + height + ")")
                .call(d3.axisBottom(xScale)
                    .tickSize(-height)
                );
         
            svgG.append("g")
                .attr("class", "grid")
                .call(d3.axisLeft(yScale)
                    .ticks(5)
                    .tickSize(-width)
                );
         
            var line = d3.line()
                   .curve(d3.curveBasis)
                .x(function(d) { return xScale(d.x); })
                .y(function(d) { return yScale(d.y); });
         
            var lineG = svgG.append("g")
                .selectAll("g")
                   .data(data)
                .enter().append("g");
         
            lineG.append("path")
                .attr("class", "lineChart")
                .style("stroke", function(d, i) { return colors( series[i]); })
                .attr("d", line);
         
            var legend = svgG.append("g")
                .attr("text-anchor", "end")
                .selectAll("g")
                .data(series)
                .enter().append("g")
                .attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });
         
            legend.append("rect")
                .attr("x", width - 20)
                .attr("width", 19)
                .attr("height", 19)
                .attr("fill", colors);
         
            legend.append("text")
                .attr("x", width - 30)
                .attr("y", 9.5)
                .attr("dy", "0.32em")
                .text(function(d) { return d; });
            
          }

         });