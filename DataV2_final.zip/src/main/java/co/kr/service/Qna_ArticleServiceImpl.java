package co.kr.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import co.kr.dao.Qna_ArticleDAO;
import co.kr.paging.Criteria;
import co.kr.vo.Qna_ArticleVO;

@Service
public class Qna_ArticleServiceImpl implements Qna_ArticleService{

	private final Qna_ArticleDAO qna_articleDAO;
	
	@Inject
	public Qna_ArticleServiceImpl(Qna_ArticleDAO qna_articleDAO) {
		this.qna_articleDAO=qna_articleDAO;
	}

	@Override
	public void create(Qna_ArticleVO qna_articleVO) throws Exception {
		qna_articleDAO.create(qna_articleVO);
	}

	@Override
	public Qna_ArticleVO read(Integer qsq) throws Exception {
		return qna_articleDAO.read(qsq);
	}

	@Override
	public void update(Qna_ArticleVO qna_articleVO) throws Exception {
		qna_articleDAO.update(qna_articleVO);
	}

	@Override
	public void delete(Integer qsq) throws Exception {
		qna_articleDAO.delete(qsq);
	}

	@Override
	public List<Qna_ArticleVO> listAll() throws Exception {
		return qna_articleDAO.listAll();
	}
	
	
	@Override 
	public List<Qna_ArticleVO> listCriteria(Criteria criteria) throws
	  Exception { return qna_articleDAO.listCriteria(criteria); }
	 
	@Override public int countArticles(Criteria criteria) throws Exception{
		  return qna_articleDAO.countArticles(criteria); }
		 
	@Override
	public void hitsUp(Integer qsq) throws Exception {
		// TODO Auto-generated method stub
		qna_articleDAO.hitsUp(qsq);
	}
	
}
