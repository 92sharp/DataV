package co.kr.service;

import java.util.List;

import co.kr.vo.VideoVO;

public interface VideoService {

	public List<VideoVO>selectVideo() throws Exception;
}
