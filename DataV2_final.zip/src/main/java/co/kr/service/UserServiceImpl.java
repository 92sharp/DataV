package co.kr.service;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import co.kr.vo.LoginDTO;
import co.kr.vo.UserFind_DTO;
import co.kr.vo.UserVO;

import co.kr.dao.UserDAO;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private final UserDAO userDAO;
	
	@Inject
	public UserServiceImpl(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	
	// ȸ������ ó��
	@Override
	public void register(UserVO userVO) throws Exception {
		// TODO Auto-generated method stub
		userDAO.register(userVO);
	}
	
	// �α��� ó��
	@Override
	public UserVO login(LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		return userDAO.login(loginDTO);
	}
	
	@Override
	public int idCheck(String userId) throws Exception {
		int result=userDAO.idCheck(userId);
		return result;
	}
	
	
	@Override
	public UserVO findId(UserFind_DTO ufDTO) throws Exception {
		return userDAO.findId(ufDTO);
	}
	
	@Override
	public UserVO findPw(UserFind_DTO ufDTO) throws Exception {
		return userDAO.findPw(ufDTO);
	}
	
	@Override
	public void update(UserVO userVO) throws Exception {
		userDAO.update(userVO);
	}
}
