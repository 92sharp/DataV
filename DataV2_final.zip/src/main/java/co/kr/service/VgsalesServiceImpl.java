package co.kr.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import co.kr.dao.VgsalesDAO;
import co.kr.vo.VgsalesVO;

@Service
public class VgsalesServiceImpl implements VgsalesService{

	@Inject
	VgsalesDAO vgsalesdao;
	
	@Override
	public List<VgsalesVO> selectVgsales() throws Exception {
		// TODO Auto-generated method stub
		return vgsalesdao.selectVgsales();
	}
	
	@Override
	public List<VgsalesVO> selectExample() throws Exception {
		return vgsalesdao.selectExample();
	}
	
	@Override
	public List<VgsalesVO> selectYear_avg() throws Exception {
		return vgsalesdao.selectYear_avg();
	}
}
