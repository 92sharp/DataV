package co.kr.service;

import java.util.List;

import co.kr.paging.Criteria;
import co.kr.vo.Qna_ArticleVO;


public interface Qna_ArticleService {

	void create(Qna_ArticleVO qna_articleVO) throws Exception;
	
	Qna_ArticleVO read(Integer qsq) throws Exception;
	
	void update(Qna_ArticleVO qna_articleVO) throws Exception;
	
	void delete(Integer qsq) throws Exception;
	
	List<Qna_ArticleVO> listAll() throws Exception;
	
	 List<Qna_ArticleVO> listCriteria(Criteria criteria) throws Exception; 

	 int countArticles(Criteria criteria) throws Exception;

	 void hitsUp(Integer qsq) throws Exception;
}
