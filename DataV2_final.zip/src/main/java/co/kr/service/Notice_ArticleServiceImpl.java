package co.kr.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import co.kr.dao.Notice_ArticleDAO;
import co.kr.paging.Criteria;
import co.kr.vo.Free_ArticleVO;
import co.kr.vo.Notice_ArticleVO;

@Service
public class Notice_ArticleServiceImpl implements Notice_ArticleService{

	private final Notice_ArticleDAO notice_articleDAO;
	
	@Inject
	public Notice_ArticleServiceImpl(Notice_ArticleDAO notice_articleDAO) {
		this.notice_articleDAO=notice_articleDAO;
	}

	@Override
	public void create(Notice_ArticleVO notice_articleVO) throws Exception {
		notice_articleDAO.create(notice_articleVO);
	}

	@Override
	public Notice_ArticleVO read(Integer nsq) throws Exception {
		return notice_articleDAO.read(nsq);
	}

	@Override
	public void update(Notice_ArticleVO notice_articleVO) throws Exception {
		notice_articleDAO.update(notice_articleVO);
	}

	@Override
	public void delete(Integer nsq) throws Exception {
		notice_articleDAO.delete(nsq);
	}

	@Override
	public List<Notice_ArticleVO> listAll() throws Exception {
		return notice_articleDAO.listAll();
	}
	
	 @Override 
	  public List<Notice_ArticleVO> listCriteria(Criteria criteria) throws Exception { 
		  return notice_articleDAO.listCriteria(criteria); }
	 
	
	
	  @Override public int countArticles(Criteria criteria) throws Exception{
	  return notice_articleDAO.countArticles(criteria); }
	 
	  @Override
		public void hitsUp(Integer nsq) throws Exception {
			// TODO Auto-generated method stub
			notice_articleDAO.hitsUp(nsq);
		}
	
	
	/*
	 * @Override public List<Notice_ArticleVO> listCriteria(Criteria criteria) throws
	 * Exception { return notice_articleDAO.listCriteria(criteria); }
	 */
}
