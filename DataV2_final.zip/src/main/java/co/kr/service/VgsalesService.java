package co.kr.service;

import java.util.List;

import co.kr.vo.VgsalesVO;

public interface VgsalesService {

	public List<VgsalesVO>selectVgsales() throws Exception;
	
	public List<VgsalesVO>selectExample() throws Exception;
	
	public List<VgsalesVO>selectYear_avg() throws Exception;
}
