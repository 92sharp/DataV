package co.kr.service;

import java.util.List;

import co.kr.paging.Criteria;
import co.kr.vo.Free_ArticleVO;
import co.kr.vo.Notice_ArticleVO;


public interface Notice_ArticleService {

	void create(Notice_ArticleVO notice_articleVO) throws Exception;
	
	Notice_ArticleVO read(Integer nsq) throws Exception;
	
	void update(Notice_ArticleVO notice_articleVO) throws Exception;
	
	void delete(Integer nsq) throws Exception;
	
	List<Notice_ArticleVO> listAll() throws Exception;
	
	List<Notice_ArticleVO> listCriteria(Criteria criteria) throws Exception;

	int countArticles(Criteria criteria) throws Exception;
	
	void hitsUp(Integer nsq) throws Exception;
	
	/* List<Notice_ArticleVO> listCriteria(Criteria criteria) throws Exception; */
}
