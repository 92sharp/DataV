package co.kr.service;

import java.util.List;

import co.kr.vo.WineVO;

public interface WineService {

	public List<WineVO>selectWine() throws Exception;
}
