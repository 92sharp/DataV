package co.kr.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import co.kr.dao.Free_ArticleDAO;
import co.kr.paging.Criteria;
import co.kr.vo.Free_ArticleVO;

@Service
public class Free_ArticleServiceImpl implements Free_ArticleService{

	private final Free_ArticleDAO free_articleDAO;
	
	@Inject
	public Free_ArticleServiceImpl(Free_ArticleDAO free_articleDAO) {
		this.free_articleDAO=free_articleDAO;
	}

	@Override
	public void create(Free_ArticleVO free_articleVO) throws Exception {
		free_articleDAO.create(free_articleVO);
	}

	@Override
	public Free_ArticleVO read(Integer fsq) throws Exception {
		return free_articleDAO.read(fsq);
	}

	@Override
	public void update(Free_ArticleVO free_articleVO) throws Exception {
		free_articleDAO.update(free_articleVO);
	}

	@Override
	public void delete(Integer fsq) throws Exception {
		free_articleDAO.delete(fsq);
	}

	@Override
	public List<Free_ArticleVO> listAll() throws Exception {
		return free_articleDAO.listAll();
	}
	
	
	  @Override 
	  public List<Free_ArticleVO> listCriteria(Criteria criteria) throws Exception { 
		  return free_articleDAO.listCriteria(criteria); }
	 
	
	
	  @Override public int countArticles(Criteria criteria) throws Exception{
	  return free_articleDAO.countArticles(criteria); }
	 
	  @Override
		public void hitsUp(Integer fsq) throws Exception {
			// TODO Auto-generated method stub
			free_articleDAO.hitsUp(fsq);
		}
	 
}
