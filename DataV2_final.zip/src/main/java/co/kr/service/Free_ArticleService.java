package co.kr.service;

import java.util.List;

import co.kr.paging.Criteria;
import co.kr.vo.Free_ArticleVO;


public interface Free_ArticleService {

	void create(Free_ArticleVO free_articleVO) throws Exception;
	
	Free_ArticleVO read(Integer fsq) throws Exception;
	
	void update(Free_ArticleVO free_articleVO) throws Exception;
	
	void delete(Integer fsq) throws Exception;
	
	List<Free_ArticleVO> listAll() throws Exception;
	
	 List<Free_ArticleVO> listCriteria(Criteria criteria) throws Exception;

	int countArticles(Criteria criteria) throws Exception;
	
	void hitsUp(Integer fsq) throws Exception;
	
	//List<Free_ArticleVO> listPaging(int page) throws Exception;
}
