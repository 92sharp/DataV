package co.kr.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import co.kr.dao.VideoDAO;
import co.kr.vo.VideoVO;

@Service
public class VideoServiceImpl implements VideoService {

	@Inject
	private VideoDAO dao;
	
	@Override
	public List<VideoVO> selectVideo() throws Exception {
		// TODO Auto-generated method stub
		return dao.selectVideo();
	}
	
}
