package co.kr.vo;

public class VgsalesVO {

	private String Name;
	private String Platform;
	private int Year_of_Release;
	private String Genre;
	private String Publisher;
	private double NA_Sales;
	private double EU_Sales;
	private double JP_Sales;
	private double Other_sales;
	private double Global_Sales;
	private int Critic_Score;
	private int Critic_Count;
	private int User_Score;
	private int User_Count;
	private String Developer;
	private String Rating;
	private int cnt;
	private double avg;
	
	
	
	
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPlatform() {
		return Platform;
	}
	public void setPlatform(String platform) {
		Platform = platform;
	}
	public int getYear_of_Release() {
		return Year_of_Release;
	}
	public void setYear_of_Release(int year_of_Release) {
		Year_of_Release = year_of_Release;
	}
	public String getGenre() {
		return Genre;
	}
	public void setGenre(String genre) {
		Genre = genre;
	}
	public String getPublisher() {
		return Publisher;
	}
	public void setPublisher(String publisher) {
		Publisher = publisher;
	}
	public double getNA_Sales() {
		return NA_Sales;
	}
	public void setNA_Sales(double nA_Sales) {
		NA_Sales = nA_Sales;
	}
	public double getEU_Sales() {
		return EU_Sales;
	}
	public void setEU_Sales(double eU_Sales) {
		EU_Sales = eU_Sales;
	}
	public double getJP_Sales() {
		return JP_Sales;
	}
	public void setJP_Sales(double jP_Sales) {
		JP_Sales = jP_Sales;
	}
	public double getOther_sales() {
		return Other_sales;
	}
	public void setOther_sales(double other_sales) {
		Other_sales = other_sales;
	}
	public double getGlobal_Sales() {
		return Global_Sales;
	}
	public void setGlobal_Sales(double global_Sales) {
		Global_Sales = global_Sales;
	}
	public int getCritic_Score() {
		return Critic_Score;
	}
	public void setCritic_Score(int critic_Score) {
		Critic_Score = critic_Score;
	}
	public int getCritic_Count() {
		return Critic_Count;
	}
	public void setCritic_Count(int critic_Count) {
		Critic_Count = critic_Count;
	}
	public int getUser_Score() {
		return User_Score;
	}
	public void setUser_Score(int user_Score) {
		User_Score = user_Score;
	}
	public int getUser_Count() {
		return User_Count;
	}
	public void setUser_Count(int user_Count) {
		User_Count = user_Count;
	}
	public String getDeveloper() {
		return Developer;
	}
	public void setDeveloper(String developer) {
		Developer = developer;
	}
	public String getRating() {
		return Rating;
	}
	public void setRating(String rating) {
		Rating = rating;
	}
	
	
	
	
}
