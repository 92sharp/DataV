package co.kr.vo;

public class VideoVO {

	private String name;
	private String platform;
	private double year_of_Release;
	private String genre;
	private String publisher;
	private double na_Sales;
	private double eu_Sales;
	private double jp_Sales;
	private double other_Sales;
	private double global_Sales;
	private int critic_Score;
	private int critic_Count;
	private double user_Score;
	private int user_Count;
	private String developer;
	private String rating;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public double getYear_of_Release() {
		return year_of_Release;
	}
	public void setYear_of_Release(double year_of_Release) {
		this.year_of_Release = year_of_Release;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public double getNa_Sales() {
		return na_Sales;
	}
	public void setNa_Sales(double na_Sales) {
		this.na_Sales = na_Sales;
	}
	public double getEu_Sales() {
		return eu_Sales;
	}
	public void setEu_Sales(double eu_Sales) {
		this.eu_Sales = eu_Sales;
	}
	public double getJp_Sales() {
		return jp_Sales;
	}
	public void setJp_Sales(double jp_Sales) {
		this.jp_Sales = jp_Sales;
	}
	public double getOther_Sales() {
		return other_Sales;
	}
	public void setOther_Sales(double other_Sales) {
		this.other_Sales = other_Sales;
	}
	public double getGlobal_Sales() {
		return global_Sales;
	}
	public void setGlobal_Sales(double global_Sales) {
		this.global_Sales = global_Sales;
	}
	public int getCritic_Score() {
		return critic_Score;
	}
	public void setCritic_Score(int critic_Score) {
		this.critic_Score = critic_Score;
	}
	public int getCritic_Count() {
		return critic_Count;
	}
	public void setCritic_Count(int critic_Count) {
		this.critic_Count = critic_Count;
	}
	public double getUser_Score() {
		return user_Score;
	}
	public void setUser_Score(double user_Score) {
		this.user_Score = user_Score;
	}
	public int getUser_Count() {
		return user_Count;
	}
	public void setUser_Count(int user_Count) {
		this.user_Count = user_Count;
	}
	public String getDeveloper() {
		return developer;
	}
	public void setDeveloper(String developer) {
		this.developer = developer;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	
	
	
	
}
