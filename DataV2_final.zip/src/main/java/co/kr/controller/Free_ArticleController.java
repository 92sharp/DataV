package co.kr.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import co.kr.paging.Criteria;
import co.kr.paging.PageMaker;
import co.kr.service.Free_ArticleService;
import co.kr.util.UploadFileUtils;
import co.kr.vo.Free_ArticleVO;


@Controller
public class Free_ArticleController {

	private static final Logger logger = LoggerFactory.getLogger(Free_ArticleController.class);

	private final Free_ArticleService free_articleService;

	@Inject
	public Free_ArticleController(Free_ArticleService free_articleService) {
		this.free_articleService=free_articleService;
	}
	
	@Resource(name="uploadPath")
	private String uploadPath;

	//�뀎怨쀬춭占쎌뿯
	@RequestMapping(value = "/free/Write", method = RequestMethod.GET)
	public String writeGET() {
		logger.info("write get筌욊쑴�뿯");

		return "/free/Write";
	}

	//占쎈쾻嚥∽옙 筌ｌ꼶�봺
	@RequestMapping(value = "/free/Write", method = RequestMethod.POST)
	public String writePOST(Free_ArticleVO free_articleVO, MultipartFile file,RedirectAttributes redirectAttributes) throws Exception {
		logger.info("write post筌욊쑴�뿯");
		
		String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.isEmpty()) {
			fileName = "none";
			free_articleVO.setGdsImg(fileName);
			free_articleVO.setGdsThumbImg(fileName);
			
			free_articleService.create(free_articleVO);
			redirectAttributes.addFlashAttribute("msg","regSuccess");
		}else {
			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			free_articleVO.setGdsImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			free_articleVO.setGdsThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
			free_articleService.create(free_articleVO);
			redirectAttributes.addFlashAttribute("msg","regSuccess");
		}
		
		
		
		return "redirect:/free/Free";
	}

	

	
	  //筌뤴뫖以� 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
	  
	  @RequestMapping(value = "/free/Free", method = RequestMethod.GET) 
	  public String listPaging(Model model,Criteria criteria) throws Exception { logger.info("Free筌욊쑴�뿯");
	  
	  logger.info("listPaging...");
	  
	  PageMaker pageMaker = new PageMaker();
	  pageMaker.setCriteria(criteria);
	  pageMaker.setTotalCount(free_articleService.countArticles(criteria));
	  
	  //model.addAttribute("free_articles",free_articleService.listAll());
	  
	  
	  model.addAttribute("free_articles", free_articleService.listCriteria(criteria));
	  model.addAttribute("pageMaker", pageMaker);
	  
	  return "/free/Free"; }
	 

	 
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	//鈺곌퀬�뵕 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
	@RequestMapping(value = "/free/Read", method = RequestMethod.GET)
	public String read(@RequestParam("fsq") int fsq,
						@ModelAttribute("criteria") Criteria criteria ,Model model) throws Exception {
		logger.info("Read筌욊쑴�뿯");

		// 조회수 증가
		free_articleService.hitsUp(fsq);
		
		model.addAttribute("free_article",free_articleService.read(fsq));

		return "/free/Read";
	}
	
	
	
	
	
	

	//占쎈땾占쎌젟 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
	@RequestMapping(value = "/free/Modify", method = RequestMethod.GET)
	public String modifyGET(@RequestParam("fsq") int fsq,
			@ModelAttribute("criteria") Criteria criteria ,Model model) throws Exception {
		logger.info("Modify GET筌욊쑴�뿯");

		model.addAttribute("free_article",free_articleService.read(fsq));

		return "/free/Modify";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//占쎈땾占쎌젟 筌ｌ꼶�봺
	@RequestMapping(value = "/free/Modify", method = RequestMethod.POST)
	public String modifyPost(Free_ArticleVO free_articleVO,
							Criteria criteria,
							MultipartFile file,
							RedirectAttributes redirectAttributes) throws Exception {
		logger.info("Modify POST筌욊쑴�뿯");

		String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.isEmpty()) {
			fileName = "none";
			free_articleVO.setGdsImg(fileName);
			free_articleVO.setGdsThumbImg(fileName);
			
			free_articleService.update(free_articleVO);
			
			redirectAttributes.addAttribute("page", criteria.getPage());
			redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
			redirectAttributes.addFlashAttribute("msg","modSuccess");
		}else {
			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			free_articleVO.setGdsImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			free_articleVO.setGdsThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
			free_articleService.update(free_articleVO);
			
			redirectAttributes.addAttribute("page", criteria.getPage());
			redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
			redirectAttributes.addFlashAttribute("msg","modSuccess");
		}
		
		
		
		return "redirect:/free/Free";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@RequestMapping(value = "/free/Remove", method = RequestMethod.POST)
	public String remove(@RequestParam("fsq") int fsq,
						Criteria criteria,
						RedirectAttributes redirectAttributes) throws Exception {
		logger.info("Remove POST筌욊쑴�뿯");

		free_articleService.delete(fsq);
		redirectAttributes.addAttribute("page", criteria.getPage());
		redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
		redirectAttributes.addFlashAttribute("msg","delSuccess");

		return "redirect:/free/Free";
	}
	
	@RequestMapping(value = "/free/listCriteria", method = RequestMethod.GET)
	public String listCriteria(Model model, Criteria criteria) throws Exception{
		logger.info("freeCriteria...");
		model.addAttribute("free_articles", free_articleService.listCriteria(criteria));
		return "/free/listcriteria";
	}
	
	
	
	
	
	

	
	

}
