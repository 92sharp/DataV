package co.kr.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import co.kr.paging.Criteria;
import co.kr.paging.PageMaker;
import co.kr.service.Notice_ArticleService;
import co.kr.util.UploadFileUtils;
import co.kr.vo.Notice_ArticleVO;

@Controller
public class Notice_ArticleController {

   private static final Logger logger = LoggerFactory.getLogger(Notice_ArticleController.class);

   private final Notice_ArticleService notice_articleService;

   @Inject
   public Notice_ArticleController(Notice_ArticleService notice_articleService) {
      this.notice_articleService=notice_articleService;
   }

   @Resource(name="uploadPath")
	private String uploadPath;
   
   //�뀎怨쀬춭占쎌뿯
   @RequestMapping(value = "/notice/Write", method = RequestMethod.GET)
   public String writeGET() {
      logger.info("write get筌욊쑴�뿯");

      return "/notice/Write";
   }

   //占쎈쾻嚥∽옙 筌ｌ꼶�봺
   @RequestMapping(value = "/notice/Write", method = RequestMethod.POST)
   public String writePOST(Notice_ArticleVO notice_articleVO,MultipartFile file,RedirectAttributes redirectAttributes) throws Exception {
      logger.info("write post筌욊쑴�뿯");
      
      String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.isEmpty()) {
			fileName = "none";
			notice_articleVO.setGdsImg(fileName);
			notice_articleVO.setGdsThumbImg(fileName);
			
			notice_articleService.create(notice_articleVO);
			redirectAttributes.addFlashAttribute("msg","regSuccess");
		}else {
			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			notice_articleVO.setGdsImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			notice_articleVO.setGdsThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
			notice_articleService.create(notice_articleVO);
			redirectAttributes.addFlashAttribute("msg","regSuccess");
		}
      
      return "redirect:/notice/Notice";
   }

   

   //筌뤴뫖以� 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
   @RequestMapping(value = "/notice/Notice", method = RequestMethod.GET)
   public String notice(Model model,Criteria criteria) throws Exception {
      logger.info("Notice筌욊쑴�뿯1");
      
      PageMaker pageMaker = new PageMaker();
      pageMaker.setCriteria(criteria);
      pageMaker.setTotalCount(notice_articleService.countArticles(criteria));
      
      model.addAttribute("notice_articles",notice_articleService.listAll());
      
      model.addAttribute("notice_articles", notice_articleService.listCriteria(criteria));
      model.addAttribute("pageMaker", pageMaker);

      return "/notice/Notice";
   }

   
   
   
   
   
   
   
   
   //鈺곌퀬�뵕 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
   @RequestMapping(value = "/notice/Read", method = RequestMethod.GET)
   public String read(@RequestParam("nsq") int nsq,
         @ModelAttribute("criteria") Criteria criteria ,Model model) throws Exception {
      logger.info("Read筌욊쑴�뿯");

      // 조회수 증가
      notice_articleService.hitsUp(nsq);
      
      model.addAttribute("notice_article",notice_articleService.read(nsq));

      return "/notice/Read";
   }

   //占쎈땾占쎌젟 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
   @RequestMapping(value = "/notice/Modify", method = RequestMethod.GET)
   public String modifyGET(@RequestParam("nsq") int nsq,
         @ModelAttribute("criteria") Criteria criteria ,Model model) throws Exception {
      logger.info("Modify GET筌욊쑴�뿯");

      model.addAttribute("notice_article",notice_articleService.read(nsq));

      return "/notice/Modify";
   }
   //占쎈땾占쎌젟 筌ｌ꼶�봺
   @RequestMapping(value = "/notice/Modify", method = RequestMethod.POST)
   public String modifyPost(Notice_ArticleVO notice_articleVO,
         Criteria criteria,
         MultipartFile file,
         RedirectAttributes redirectAttributes) throws Exception {
      logger.info("Modify POST筌욊쑴�뿯");

      String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.isEmpty()) {
			fileName = "none";
			notice_articleVO.setGdsImg(fileName);
			notice_articleVO.setGdsThumbImg(fileName);
			
			notice_articleService.update(notice_articleVO);
			
			redirectAttributes.addAttribute("page", criteria.getPage());
			redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
			redirectAttributes.addFlashAttribute("msg","modSuccess");
		}else {
			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			notice_articleVO.setGdsImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			notice_articleVO.setGdsThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
			notice_articleService.update(notice_articleVO);
			
			redirectAttributes.addAttribute("page", criteria.getPage());
			redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
			redirectAttributes.addFlashAttribute("msg","modSuccess");
		}

      return "redirect:/notice/Notice";
   }

   @RequestMapping(value = "notice/Remove", method = RequestMethod.POST)
   public String remove(@RequestParam("nsq") int nsq,
         Criteria criteria,
         RedirectAttributes redirectAttributes) throws Exception {
      logger.info("Remove POST筌욊쑴�뿯");

      notice_articleService.delete(nsq);
      redirectAttributes.addAttribute("page", criteria.getPage());
      redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
      redirectAttributes.addFlashAttribute("msg","delSuccess");

      return "redirect:/notice/Notice";
   }
   
   

}