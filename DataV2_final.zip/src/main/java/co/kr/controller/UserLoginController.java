package co.kr.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import co.kr.service.UserService;
import co.kr.vo.LoginDTO;
import co.kr.vo.UserVO;

@Controller
public class UserLoginController {

	private final UserService userService;
	
	@Inject
	public UserLoginController(UserService userService) {
		this.userService = userService;
	}

	// �α��� ������
	@RequestMapping(value="/login/Login", method = RequestMethod.GET)
	public String loginGET(@ModelAttribute("loginDTO") LoginDTO loginDTO) throws Exception {
		return "/login/Login";
	}


	// �α��� ó��
	@RequestMapping(value="/login/loginPost", method= RequestMethod.POST)
	public void loginPOST(LoginDTO loginDTO, HttpSession httpSession, Model model) throws Exception{
		
		//System.out.println(loginDTO.getUserId());
	
		
		try {
			UserVO userVO = userService.login(loginDTO);
			
			
			//System.out.println(userVO.getUserId());
			System.out.println(loginDTO.getUserPw()+" "+userVO.getUserPw());
			////////�н����� Ȯ�� ���� ó���ؾ���/////
			
			if(userVO==null||!BCrypt.checkpw(loginDTO.getUserPw(), userVO.getUserPw())) {
				return;
			}
			 

			model.addAttribute("user",userVO);
		} catch (NullPointerException e) {
			e.printStackTrace();
			return;
		}
		
	}

	//로그아웃 처리
	@RequestMapping(value="/login/Logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request,
						 HttpServletResponse response,
						 HttpSession httpSession) throws Exception{
		Object object=httpSession.getAttribute("login");
		if(object !=null ) {
			UserVO userVO=(UserVO)object;
			httpSession.removeAttribute("login");
			httpSession.invalidate();
		}
		return "/login/Logout";
	}
	
	/*
	 * @RequestMapping(value = "/Login", method = RequestMethod.GET) public String
	 * LoginGET(@ModelAttribute("loginDTO") LoginDTO loginDTO) {
	 * 
	 * return "Login"; }
	 * 
	 * @RequestMapping(value = "/LoginPost", method = RequestMethod.POST) public
	 * void LoginPOST(LoginDTO loginDTO, HttpSession httpSession, Model model)throws
	 * Exception {
	 * 
	 * UserVO userVO=userService.login(loginDTO);
	 * 
	 * if(userVO==null||!BCrypt.checkpw(loginDTO.getPassword(),
	 * userVO.getPassword())) { return; } model.addAttribute("user",userVO); }
	 */
}
