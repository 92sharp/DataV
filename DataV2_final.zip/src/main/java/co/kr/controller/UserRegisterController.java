package co.kr.controller;

import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import co.kr.service.UserService;
import co.kr.vo.UserVO;

@Controller
public class UserRegisterController {
	
	@Autowired
	private final UserService userService;
	
	@Inject
	public UserRegisterController(UserService userService) {
		this.userService = userService;
	}
	
	@RequestMapping(value="/login/Success", method = RequestMethod.GET)
	public String successGET() throws Exception {
		return "/login/Success";
	}
	
	// ȸ������ ������
	@RequestMapping(value="/login/JoinUser", method = RequestMethod.GET)
	public String registerGET() throws Exception {
		return "/login/JoinUser";
	}
	
	// 회원가입 처리
	   @RequestMapping(value="/login/JoinUser", method = RequestMethod.POST)
	   public String registerPOST(UserVO userVO, RedirectAttributes redirectAttributes) throws Exception{
	      
	      String hashedPw = BCrypt.hashpw(userVO.getUserPw(),BCrypt.gensalt());
	      
	      
	      System.out.println("확인확인확인----"+userVO.getUserId());
	      userVO.setUserPw(hashedPw);
	      userService.register(userVO);
	      redirectAttributes.addFlashAttribute("msg", "REGISTERED");
	      
	      
	      return "redirect:/login/Success";
	   }
	
	
	@RequestMapping(value="/idCheck", method = RequestMethod.GET, produces = "application/text; charset=utf8")
	@ResponseBody
	public String idCheck(HttpServletRequest request) throws Exception {
		String userId=request.getParameter("userId");
		int result=userService.idCheck(userId);
		return Integer.toString(result);
	}
	
	
	
	/*
	 * @RequestMapping(value = "/UserFind", method = RequestMethod.POST)
	 * 
	 * @ResponseBody public String UserFind(@RequestParam("name1") String
	 * name1,@RequestParam("email1") String email1)throws Exception {
	 * 
	 * String result=
	 * 
	 * }
	 */
}
