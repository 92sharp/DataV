package co.kr.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import co.kr.paging.Criteria;
import co.kr.service.UserService;
import co.kr.vo.Free_ArticleVO;
import co.kr.vo.UserFind_DTO;
import co.kr.vo.UserVO;

@Controller
public class UserFindController {

	private final UserService userService;
	
	@Inject
	public UserFindController(UserService userService) {
		this.userService=userService;
	}
	
	@RequestMapping(value="/login/UserFind", method = RequestMethod.GET)
	public String UserFindGET() throws Exception {
		return "/login/UserFind";
	}
	
	@RequestMapping(value="/UserFind", method = RequestMethod.GET, produces = "application/text; charset=utf8")
	@ResponseBody
	public String UserFind(UserFind_DTO ufDTO,HttpServletRequest request,Model model) throws Exception {
		
		
		String userName = request.getParameter("userName");
		String userEmail = request.getParameter("userEmail");
		
		System.out.println(userName);
		System.out.println(userEmail);
		
		ufDTO.setUserName(userName);
		ufDTO.setUserEmail(userEmail);
		
		UserVO userVO=userService.findId(ufDTO);
		
		System.out.println("DTO"+ufDTO.getUserName());
		System.out.println("DTO"+ufDTO.getUserEmail());
		
		if(userVO==null) {
			return "";
		}else {
			String userId=userVO.getUserId();
			return userId;
		}
		
	}
	
	@RequestMapping(value="/PassFind", method = RequestMethod.GET, produces = "application/text; charset=utf8")
	@ResponseBody
	public String PassFind(UserFind_DTO ufDTO,HttpServletRequest request,Model model) throws Exception {
		
		String userId = request.getParameter("userId");
		String userName = request.getParameter("userName");
		String userEmail = request.getParameter("userEmail");
		
		
		
		System.out.println(userId);
		System.out.println(userName);
		System.out.println(userEmail);
		
		ufDTO.setUserId(userId);
		ufDTO.setUserName(userName);
		ufDTO.setUserEmail(userEmail);
		
		UserVO userVO=userService.findPw(ufDTO);
		
		System.out.println("DTO"+ufDTO.getUserId());
		System.out.println("DTO"+ufDTO.getUserName());
		System.out.println("DTO"+ufDTO.getUserEmail());
		
		if(userVO==null) {
			return "";
		}else {
			String userPw=userVO.getUserPw();
			return userPw;
		}
		
	}
	
	
	@RequestMapping(value = "/PassUpd", method = RequestMethod.POST)
	public String modifyPost(UserVO userVO,
							RedirectAttributes redirectAttributes) throws Exception {
		
		System.out.println(userVO.getUserId());
		System.out.println(userVO.getUserPw());
		
		String hashedPw = BCrypt.hashpw(userVO.getUserPw(),BCrypt.gensalt());
		userVO.setUserPw(hashedPw);
		
		userService.update(userVO);
		redirectAttributes.addFlashAttribute("msg", "REGISTERED");
		
		 return "/login/Login"; 
	}
}
