package co.kr.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import co.kr.paging.Criteria;
import co.kr.paging.PageMaker;
import co.kr.service.Qna_ArticleService;
import co.kr.util.UploadFileUtils;
import co.kr.vo.Qna_ArticleVO;

@Controller
public class Qna_ArticleController {

   private static final Logger logger = LoggerFactory.getLogger(Qna_ArticleController.class);

   private final Qna_ArticleService qna_articleService;

   @Inject
   public Qna_ArticleController(Qna_ArticleService qna_articleService) {
      this.qna_articleService=qna_articleService;
   }

   @Resource(name="uploadPath")
	private String uploadPath;
   
   //�뀎怨쀬춭占쎌뿯
   @RequestMapping(value = "/qna/Write", method = RequestMethod.GET)
   public String writeGET() {
      logger.info("qna write get筌욊쑴�뿯");

      /* return "/qna/Write"; */
      return "/qna/Write";
   }

   //占쎈쾻嚥∽옙 筌ｌ꼶�봺
   @RequestMapping(value = "/qna/Write", method = RequestMethod.POST)
   public String writePOST(Qna_ArticleVO qna_articleVO,MultipartFile file,RedirectAttributes redirectAttributes) throws Exception {
      logger.info("qna write post筌욊쑴�뿯");
      
      String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.isEmpty()) {
			fileName = "none";
			qna_articleVO.setGdsImg(fileName);
			qna_articleVO.setGdsThumbImg(fileName);
			
			qna_articleService.create(qna_articleVO);
			redirectAttributes.addFlashAttribute("msg","regSuccess");
		}else {
			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			qna_articleVO.setGdsImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			qna_articleVO.setGdsThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
			qna_articleService.create(qna_articleVO);
			redirectAttributes.addFlashAttribute("msg","regSuccess");
		}
      return "redirect:/qna/Qna";
   }

   

   //value
   @RequestMapping(value = "/qna/Qna", method = RequestMethod.GET)
   public String qna(Model model,Criteria criteria) throws Exception {
      logger.info("Qna筌욊쑴�뿯1");

        PageMaker pageMaker = new PageMaker();
        pageMaker.setCriteria(criteria);
        pageMaker.setTotalCount(qna_articleService.countArticles(criteria));
        
      
      model.addAttribute("qna_articles",qna_articleService.listCriteria(criteria));
      model.addAttribute("pageMaker", pageMaker);

      return "/qna/Qna";
   }

   //鈺곌퀬�뵕 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
   @RequestMapping(value = "/qna/Read", method = RequestMethod.GET)
   public String read(@RequestParam("qsq") int qsq,
         @ModelAttribute("criteria") Criteria criteria,
         Model model) throws Exception {
      logger.info("Read筌욊쑴�뿯");

      // 조회수 증가
      qna_articleService.hitsUp(qsq);
      
      model.addAttribute("qna_article",qna_articleService.read(qsq));

      return "/qna/Read";
   }

   //占쎈땾占쎌젟 占쎈읂占쎌뵠筌욑옙 占쎌뵠占쎈짗
   @RequestMapping(value = "/qna/Modify", method = RequestMethod.GET)
   public String modifyGET(@RequestParam("qsq") int qsq,
         @ModelAttribute("criteria") Criteria criteria,Model model) throws Exception {
      logger.info("Modify GET筌욊쑴�뿯");

      model.addAttribute("qna_article",qna_articleService.read(qsq));

      return "/qna/Modify";
   }
   //占쎈땾占쎌젟 筌ｌ꼶�봺
   @RequestMapping(value = "/qna/Modify", method = RequestMethod.POST)
   public String modifyPost(Qna_ArticleVO qna_articleVO,
         Criteria criteria,
         MultipartFile file,
         RedirectAttributes redirectAttributes) throws Exception {
      logger.info("Modify POST筌욊쑴�뿯");

      String imgUploadPath = uploadPath + File.separator + "imgUpload";
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		String fileName = null;
		
		if(file.isEmpty()) {
			fileName = "none";
			qna_articleVO.setGdsImg(fileName);
			qna_articleVO.setGdsThumbImg(fileName);
			
			qna_articleService.update(qna_articleVO);
			
			redirectAttributes.addAttribute("page", criteria.getPage());
			redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
			redirectAttributes.addFlashAttribute("msg","modSuccess");
		}else {
			fileName =  UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			qna_articleVO.setGdsImg(File.separator + "imgUpload" + ymdPath + File.separator + fileName);
			qna_articleVO.setGdsThumbImg(File.separator + "imgUpload" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
			
			qna_articleService.update(qna_articleVO);
			
			redirectAttributes.addAttribute("page", criteria.getPage());
			redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
			redirectAttributes.addFlashAttribute("msg","modSuccess");
		}

      return "redirect:/qna/Qna";
   }

   @RequestMapping(value = "qna/Remove", method = RequestMethod.POST)
   public String remove(@RequestParam("qsq") int qsq,
         Criteria criteria,
         RedirectAttributes redirectAttributes) throws Exception {
      logger.info("Remove POST筌욊쑴�뿯");

      qna_articleService.delete(qsq);
      redirectAttributes.addAttribute("page", criteria.getPage());
      redirectAttributes.addAttribute("perPageNum", criteria.getPerPageNum());
      redirectAttributes.addFlashAttribute("msg","delSuccess");

      return "redirect:/qna/Qna";
   }

}