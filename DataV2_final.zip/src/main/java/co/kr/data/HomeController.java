package co.kr.data;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	
	/*
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	public String Login(Locale locale, Model model) {
		logger.info("Login 占쎌젔占쎈꺗");
		
		
		return "/login/Login";
	}
*/
	@RequestMapping(value = "/Intro", method = RequestMethod.GET)
	public String Intro(Locale locale, Model model) {
		logger.info("Intro 占쎌젔占쎈꺗");
		
		
		return "Intro";
	}
	
	@RequestMapping(value = "/login/PassUp", method = RequestMethod.GET)
	public String pass(Locale locale, Model model) {
		logger.info("Intro �젒�냽");
		
		
		return "/login/PassUp";
	}
	
/*
	@RequestMapping(value = "/Free", method = RequestMethod.GET)
	public String Free(Locale locale, Model model) {
		logger.info("Free �젒�냽");
		
		
		return "/free/Free";
	}
*/
	/*
	 * @RequestMapping(value = "/Free", method = RequestMethod.GET) public String
	 * Free(Locale locale, Model model) { logger.info("Free �젒�냽");
	 * 
	 * 
	 * return "/free/Free"; }
	 */

	

	@RequestMapping(value = "/visual/Visual", method = RequestMethod.GET)
	public String Visual(Locale locale, Model model) {
		logger.info("Visual 占쎌젔占쎈꺗");
		
		
		return "/visual/Visual";
	}
	
	
	/*
	 * @RequestMapping(value = "/UserFind", method = RequestMethod.GET) public
	 * String UserFind(Locale locale, Model model) { logger.info("UserFind 占쎌젔占쎈꺗");
	 * 
	 * 
	 * return "/login/UserFind"; }
	 */
	
	@RequestMapping(value = "/JoinUser", method = RequestMethod.GET)
	public String JoinUser(Locale locale, Model model) {
		logger.info("JoinUser 占쎌젔占쎈꺗");


		return "/login/JoinUser";
	}
	
	@RequestMapping(value = "/Success", method = RequestMethod.GET)
	public String success(Locale locale, Model model) {
		logger.info("success 占쎌젔占쎈꺗");
		
		
		return "/login/Success";
	}
	
	@RequestMapping(value = "/del", method = RequestMethod.GET)
	public String del(Locale locale, Model model) {
		logger.info("Intro 占쎌젔占쎈꺗");
		
		
		return "del";
	}
	
}
