package co.kr.util;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.WebUtils;

import co.kr.service.UserService;
import co.kr.vo.UserVO;

public class AuthInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);
	
	//페이지 정보 저장
		private void saveDestination(HttpServletRequest request) {
			String uri=request.getRequestURI();   
			String query=request.getQueryString();
			
			if(query==null||query.equals("null")) {
				query="";
			}else {
				query="?"+query;
			}
			
			if(request.getMethod().equals("GET")) {
				logger.info("destination: "+(uri+query));
				
				request.getSession().setAttribute("destination", uri+query);
				
			}
		}
	
		@Override
		public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
				throws Exception {
			
			HttpSession httpSession = request.getSession();
			
			if(httpSession.getAttribute("login")==null) {
				logger.info("로그인된 유저를 찾을 수 없습니다.");
				saveDestination(request);
				response.sendRedirect("/data/login/Login");
				return false;
			}
			
			return true;
		}

	/*
	private void saveDestination(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String uri = request.getRequestURI();
		String query = request.getQueryString();
		if(query == null || query.equals("null")) {
			query = "";
		} else {
			query = "?"+query;
		}
		
		// ���� ������ + get �Ķ���� ����
		if(request.getMethod().equals("GET")) {
			logger.info("destination: " + (uri+query));
			request.getSession().setAttribute("destination", uri+query);
		}
		
	}
	*/
}
