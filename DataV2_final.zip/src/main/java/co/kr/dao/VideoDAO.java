package co.kr.dao;

import java.util.List;

import co.kr.vo.VideoVO;

public interface VideoDAO {

	public List<VideoVO>selectVideo() throws Exception;
}
