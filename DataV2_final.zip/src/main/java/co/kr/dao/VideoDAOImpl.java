package co.kr.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import co.kr.vo.VideoVO;

@Repository
public class VideoDAOImpl implements VideoDAO {

	
	@Inject
	private SqlSession sqlSession;
	
	private static final String Namespace = "co.kr.mybatis.sql.videoMapper";
	
	@Override
	public List<VideoVO> selectVideo() throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.selectList(Namespace+".selectVideo");
	}
	

}
