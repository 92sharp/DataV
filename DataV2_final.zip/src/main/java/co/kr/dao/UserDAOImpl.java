package co.kr.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import co.kr.vo.LoginDTO;
import co.kr.vo.UserFind_DTO;
import co.kr.vo.UserVO;

@Repository
public class UserDAOImpl implements UserDAO {

	private static final String NAMESPACE = "co.kr.mybatis.sql.userMapper";
	
	@Autowired
	private final SqlSession sqlSession;
	
	@Inject
	public UserDAOImpl(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	// ȸ������ ó��
	@Override
	public void register(UserVO userVO) throws Exception {
		// TODO Auto-generated method stub
		sqlSession.insert(NAMESPACE + ".register", userVO);
	}
	
	//�α��� ó��
	
	@Override
	public UserVO login(LoginDTO loginDTO) throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.selectOne(NAMESPACE+".login", loginDTO);
	}
	
	@Override
	public int idCheck(String userId) throws Exception {
		int result=sqlSession.selectOne(NAMESPACE+".chkid",userId);
		return result;
	}
	
	
	
	@Override
	public UserVO findId(UserFind_DTO ufDTO) throws Exception {
		return sqlSession.selectOne(NAMESPACE+".findid",ufDTO);
	}
	
	@Override
	public UserVO findPw(UserFind_DTO ufDTO) throws Exception {
		return sqlSession.selectOne(NAMESPACE+".findpw",ufDTO);
	}
	
	@Override
	public void update(UserVO userVO) throws Exception {
		sqlSession.update(NAMESPACE+".passup",userVO);
	}
}
