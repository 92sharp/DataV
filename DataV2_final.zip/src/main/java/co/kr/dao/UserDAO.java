package co.kr.dao;

import co.kr.vo.LoginDTO;
import co.kr.vo.UserFind_DTO;
import co.kr.vo.UserVO;

public interface UserDAO {

	// ȸ������ ó��
	void register(UserVO userVO) throws Exception;
	
	// �α��� ó��
	UserVO login(LoginDTO loginDTO) throws Exception;
	
	public int idCheck(String userId) throws Exception;
	
	UserVO findId(UserFind_DTO ufDTO) throws Exception;
	
	UserVO findPw(UserFind_DTO ufDTO) throws Exception;
	
	void update(UserVO userVO) throws Exception;
}
