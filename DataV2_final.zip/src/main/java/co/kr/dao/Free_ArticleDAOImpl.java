package co.kr.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession; import
org.springframework.stereotype.Repository;

import co.kr.paging.Criteria;
import co.kr.vo.Free_ArticleVO;


@Repository 
public class Free_ArticleDAOImpl implements Free_ArticleDAO{

	private static final String NAMESPACE="co.kr.mybatis.sql.free_article";

	private final SqlSession sqlSession;

	@Inject public Free_ArticleDAOImpl(SqlSession sqlSession) {
		this.sqlSession=sqlSession; }

	@Override public void create(Free_ArticleVO free_articleVO) throws Exception
	{ sqlSession.insert(NAMESPACE+".create",free_articleVO); }

	@Override public Free_ArticleVO read(Integer fsq) throws Exception { return
			sqlSession.selectOne(NAMESPACE+".read",fsq); }

	@Override public void update(Free_ArticleVO free_articleVO) throws Exception
	{ sqlSession.update(NAMESPACE+".update",free_articleVO); }

	@Override public void delete(Integer fsq) throws Exception {
		sqlSession.delete(NAMESPACE+".delete",fsq); }

	@Override public List<Free_ArticleVO> listAll() throws Exception { return
			sqlSession.selectList(NAMESPACE+".listAll"); }

	
	  @Override public List<Free_ArticleVO> listPaging(int page) throws Exception {
	  
	  if(page<=0) { 
		  page=1; 
	}
	  
	  page=(page-1)*10;
	  
	  return sqlSession.selectList(NAMESPACE+".listPaging",page); 
	 }
	  
	  
	  
	
	  @Override 
	  public List<Free_ArticleVO> listCriteria(Criteria criteria) throws Exception { 
		  return sqlSession.selectList(NAMESPACE+".listCriteria",criteria);
	  }
	 
	
	  @Override
	  public int countArticles(Criteria criteria) throws Exception{
	  return sqlSession.selectOne(NAMESPACE + ".countArticles", criteria); }
	 
	  @Override
		public void hitsUp(Integer fsq) throws Exception {
			// TODO Auto-generated method stub
			 sqlSession.update(NAMESPACE + ".hitsUp", fsq);
		}
	 
}
