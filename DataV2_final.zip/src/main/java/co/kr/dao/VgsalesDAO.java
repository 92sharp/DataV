package co.kr.dao;

import java.util.List;

import co.kr.vo.VgsalesVO;

public interface VgsalesDAO {

	public List<VgsalesVO>selectVgsales() throws Exception;
	
	public List<VgsalesVO>selectExample() throws Exception;
	
	public List<VgsalesVO>selectYear_avg() throws Exception;
}
