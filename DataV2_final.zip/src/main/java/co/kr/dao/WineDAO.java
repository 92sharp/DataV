package co.kr.dao;

import java.util.List;

import co.kr.vo.WineVO;

public interface WineDAO {

	public List<WineVO>selectWine() throws Exception;
}
