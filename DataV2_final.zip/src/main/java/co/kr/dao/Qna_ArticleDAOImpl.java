package co.kr.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession; import
org.springframework.stereotype.Repository;

import co.kr.paging.Criteria;
import co.kr.vo.Qna_ArticleVO;


@Repository 
public class Qna_ArticleDAOImpl implements Qna_ArticleDAO{

	private static final String NAMESPACE="co.kr.mybatis.sql.qna_article";

	private final SqlSession sqlSession;

	@Inject public Qna_ArticleDAOImpl(SqlSession sqlSession) {
		this.sqlSession=sqlSession; }

	@Override public void create(Qna_ArticleVO qna_articleVO) throws Exception
	{ sqlSession.insert(NAMESPACE+".create",qna_articleVO); }

	@Override public Qna_ArticleVO read(Integer qsq) throws Exception { return
			sqlSession.selectOne(NAMESPACE+".read",qsq); }

	@Override public void update(Qna_ArticleVO qna_articleVO) throws Exception
	{ sqlSession.update(NAMESPACE+".update",qna_articleVO); }

	@Override public void delete(Integer qsq) throws Exception {
		sqlSession.delete(NAMESPACE+".delete",qsq); }

	@Override public List<Qna_ArticleVO> listAll() throws Exception { return
			sqlSession.selectList(NAMESPACE+".listAll"); }

	
	  @Override public List<Qna_ArticleVO> listPaging(int page) throws Exception {
	  
	  if(page<=0) { page=1; }
	  
	  page=(page-1)*10;
	  
	  return sqlSession.selectList(NAMESPACE+".listPaging",page); }
	  
	  @Override public List<Qna_ArticleVO> listCriteria(Criteria criteria) throws
	  Exception { return sqlSession.selectList(NAMESPACE+".listCriteria",criteria);
	  }
	 
	  @Override
	  public int countArticles(Criteria criteria) throws Exception{
	  return sqlSession.selectOne(NAMESPACE + ".countArticles", criteria); }
	 
	  @Override
		public void hitsUp(Integer qsq) throws Exception {
			// TODO Auto-generated method stub
			  sqlSession.update(NAMESPACE + ".hitsUp", qsq);
		}
	  
}
