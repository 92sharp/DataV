package co.kr.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession; import
org.springframework.stereotype.Repository;

import co.kr.paging.Criteria;
import co.kr.vo.Notice_ArticleVO;


@Repository 
public class Notice_ArticleDAOImpl implements Notice_ArticleDAO{

	private static final String NAMESPACE="co.kr.mybatis.sql.notice_article";

	private final SqlSession sqlSession;

	@Inject public Notice_ArticleDAOImpl(SqlSession sqlSession) {
		this.sqlSession=sqlSession; }

	@Override public void create(Notice_ArticleVO notice_articleVO) throws Exception
	{ sqlSession.insert(NAMESPACE+".create",notice_articleVO); }

	@Override public Notice_ArticleVO read(Integer nsq) throws Exception { return
			sqlSession.selectOne(NAMESPACE+".read",nsq); }

	@Override public void update(Notice_ArticleVO notice_articleVO) throws Exception
	{ sqlSession.update(NAMESPACE+".update",notice_articleVO); }

	@Override public void delete(Integer nsq) throws Exception {
		sqlSession.delete(NAMESPACE+".delete",nsq); }

	@Override public List<Notice_ArticleVO> listAll() throws Exception { return
			sqlSession.selectList(NAMESPACE+".listAll"); }

	
	  @Override 
	  public List<Notice_ArticleVO> listPaging(int page) throws Exception {
	  
	  if(page<=0) {
		  page=1; 
		  }
	  
	  page=(page-1)*10;
	  
	  return sqlSession.selectList(NAMESPACE+".listPaging",page); 
	  }
	  
	  @Override public List<Notice_ArticleVO> listCriteria(Criteria criteria) throws
	  Exception { return sqlSession.selectList(NAMESPACE+".listCriteria",criteria);
	  }
	  
	  @Override
	  public int countArticles(Criteria criteria) throws Exception{
	  return sqlSession.selectOne(NAMESPACE + ".countArticles", criteria); }
	 
	  @Override
		public void hitsUp(Integer nsq) throws Exception {
			// TODO Auto-generated method stub
			 sqlSession.update(NAMESPACE + ".hitsUp", nsq);
		}
	 
}
