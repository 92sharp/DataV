package co.kr.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import co.kr.vo.VgsalesVO;

@Repository
public class VgsalesDAOImpl implements VgsalesDAO{
	
	@Inject
	private SqlSession sqlSession;
	
	private static final String Namespace = "co.kr.mybatis.sql.vgsales";
	
	@Override
	public List<VgsalesVO> selectVgsales() throws Exception {
		return sqlSession.selectList(Namespace+".selectVgsales");
	}
	
	@Override
	public List<VgsalesVO> selectExample() throws Exception {
		return sqlSession.selectList(Namespace+".selectExam");
	}
	
	@Override
	public List<VgsalesVO> selectYear_avg() throws Exception {
		return sqlSession.selectList(Namespace+".year_avg");
	}
}
